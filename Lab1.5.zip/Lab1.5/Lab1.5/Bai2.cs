﻿using System;
using System.Collections.Generic;

// Lớp trừu tượng Hinh
public abstract class Hinh
{
    public abstract double ChuVi();
    public abstract double DienTich();
}

// Lớp HinhTron kế thừa từ Hinh
public class HinhTron : Hinh
{
    private double banKinh;

    public HinhTron(double banKinh)
    {
        this.banKinh = banKinh;
    }

    public override double ChuVi()
    {
        return 2 * Math.PI * banKinh;
    }

    public override double DienTich()
    {
        return Math.PI * banKinh * banKinh;
    }
}

// Lớp HinhVuong kế thừa từ Hinh
public class HinhVuong : Hinh
{
    private double canh;

    public HinhVuong(double canh)
    {
        this.canh = canh;
    }

    public override double ChuVi()
    {
        return 4 * canh;
    }

    public override double DienTich()
    {
        return canh * canh;
    }
}

// Lớp HinhTamGiac kế thừa từ Hinh
public class HinhTamGiac : Hinh
{
    private double a, b, c;

    public HinhTamGiac(double a, double b, double c)
    {
        this.a = a;
        this.b = b;
        this.c = c;
    }

    public override double ChuVi()
    {
        return a + b + c;
    }

    public override double DienTich()
    {
        // Công thức Heron
        double p = (a + b + c) / 2; // Nửa chu vi
        return Math.Sqrt(p * (p - a) * (p - b) * (p - c));
    }
}

// Lớp HinhChuNhat kế thừa từ Hinh
public class HinhChuNhat : Hinh
{
    private double dai, rong;

    public HinhChuNhat(double dai, double rong)
    {
        this.dai = dai;
        this.rong = rong;
    }

    public override double ChuVi()
    {
        return 2 * (dai + rong);
    }

    public override double DienTich()
    {
        return dai * rong;
    }
}

// Chương trình chính
class Program
{
    static void Main(string[] args)
    {
        List<Hinh> danhSachHinh = new List<Hinh>();
        double tongChuVi = 0, tongDienTich = 0;

        Console.WriteLine("Nhap so luong hinh:");
        int n = int.Parse(Console.ReadLine());

        for (int i = 0; i < n; i++)
        {
            Console.WriteLine($"Nhap hinh thu {i + 1}:");
            Console.WriteLine("Chon loai hinh (1: Tron, 2: Vuong, 3: Tam Giac, 4: Chu Nhat):");
            int loaiHinh = int.Parse(Console.ReadLine());

            switch (loaiHinh)
            {
                case 1: // Hình tròn
                    Console.Write("Nhap ban kinh: ");
                    double banKinh = double.Parse(Console.ReadLine());
                    danhSachHinh.Add(new HinhTron(banKinh));
                    break;

                case 2: // Hình vuông
                    Console.Write("Nhap do dai canh: ");
                    double canh = double.Parse(Console.ReadLine());
                    danhSachHinh.Add(new HinhVuong(canh));
                    break;

                case 3: // Hình tam giác
                    Console.Write("Nhap do dai 3 canh (a b c): ");
                    string[] canhTamGiac = Console.ReadLine().Split();
                    double a = double.Parse(canhTamGiac[0]);
                    double b = double.Parse(canhTamGiac[1]);
                    double c = double.Parse(canhTamGiac[2]);
                    danhSachHinh.Add(new HinhTamGiac(a, b, c));
                    break;

                case 4: // Hình chữ nhật
                    Console.Write("Nhap chieu dai va chieu rong (dai rong): ");
                    string[] kichThuoc = Console.ReadLine().Split();
                    double dai = double.Parse(kichThuoc[0]);
                    double rong = double.Parse(kichThuoc[1]);
                    danhSachHinh.Add(new HinhChuNhat(dai, rong));
                    break;

                default:
                    Console.WriteLine("Loai hinh khong hop le!");
                    i--; // Giảm i để nhập lại hình này
                    break;
            }
        }

        // Tính tổng chu vi và diện tích
        foreach (Hinh hinh in danhSachHinh)
        {
            tongChuVi += hinh.ChuVi();
            tongDienTich += hinh.DienTich();
        }

        // In kết quả
        Console.WriteLine($"Tong chu vi: {tongChuVi:F2}");
        Console.WriteLine($"Tong dien tich: {tongDienTich:F2}");
    }
}