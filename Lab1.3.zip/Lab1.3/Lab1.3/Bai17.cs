﻿//using System;
//using System.Collections.Generic;
//using System.Text;

//class Diem
//{
//    public float x, y;

//    public Diem()
//    {
//        x = 0;
//        y = 0;
//    }

//    public Diem(float x, float y)
//    {
//        this.x = x;
//        this.y = y;
//    }

//    public void InDiem()
//    {
//        Console.WriteLine($"({x}, {y})");
//    }

//    public double TinhKhoangCach(Diem d2)
//    {
//        return Math.Sqrt(Math.Pow(x - d2.x, 2) + Math.Pow(y - d2.y, 2));
//    }
//}

//class HinhTron
//{
//    public Diem tam;
//    public float banKinh;

//    public HinhTron()
//    {
//        tam = new Diem();
//        banKinh = 0;
//    }

//    public HinhTron(Diem d, float bk)
//    {
//        tam = d;
//        banKinh = bk;
//    }

//    public double ChuVi()
//    {
//        return 2 * Math.PI * banKinh;
//    }

//    public double DienTich()
//    {
//        return Math.PI * banKinh * banKinh;
//    }

//    public bool GiaoNhau(HinhTron ht2)
//    {
//        double khoangCachTam = tam.TinhKhoangCach(ht2.tam);
//        return khoangCachTam <= (banKinh + ht2.banKinh);
//    }

//    public void InThongTin()
//    {
//        Console.WriteLine($"Tam: ({tam.x}, {tam.y}), Ban kinh: {banKinh}");
//    }
//}

//class Program
//{
//    static void Main()
//    {
//        Console.OutputEncoding = Encoding.UTF8;

//        Console.Write("Nhap so hinh tron: ");
//        int n = int.Parse(Console.ReadLine());

//        List<HinhTron> danhSach = new List<HinhTron>();

//        for (int i = 0; i < n; i++)
//        {
//            Console.WriteLine($"\nNhap thong tin hinh tron thu {i + 1}:");
//            Console.Write("Nhap hoanh do tam: ");
//            float x = float.Parse(Console.ReadLine());
//            Console.Write("Nhap tung do tam: ");
//            float y = float.Parse(Console.ReadLine());
//            Console.Write("Nhap ban kinh: ");
//            float bk = float.Parse(Console.ReadLine());

//            HinhTron ht = new HinhTron(new Diem(x, y), bk);
//            danhSach.Add(ht);
//        }

//        // Tim hinh tron giao voi nhieu hinh tron nhat
//        int maxDem = 0;
//        HinhTron hinhTronMax = null;

//        foreach (var ht1 in danhSach)
//        {
//            int dem = 0;
//            foreach (var ht2 in danhSach)
//            {
//                if (ht1 != ht2 && ht1.GiaoNhau(ht2))
//                    dem++;
//            }

//            if (dem > maxDem)
//            {
//                maxDem = dem;
//                hinhTronMax = ht1;
//            }
//        }

//        Console.WriteLine("\nHinh tron giao nhieu nhat voi cac hinh tron khac:");
//        hinhTronMax.InThongTin();
//        Console.WriteLine($"So lan giao nhau: {maxDem}");
//    }
//}
