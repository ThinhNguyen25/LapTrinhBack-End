﻿//using System;
//using System.Collections.Generic;
//using System.Linq;

//namespace QuanLyKhachSan
//{
//    // Lớp quản lý thông tin cá nhân
//    public class Nguoi
//    {
//        public string HoTen { get; set; }
//        public int NamSinh { get; set; }
//        public string SoCMND { get; set; }

//        public Nguoi() { }

//        public Nguoi(string hoTen, int namSinh, string soCMND)
//        {
//            HoTen = hoTen;
//            NamSinh = namSinh;
//            SoCMND = soCMND;
//        }

//        // Phương thức nhập thông tin
//        public virtual void Nhap()
//        {
//            Console.Write("Nhập họ và tên: ");
//            HoTen = Console.ReadLine();
//            Console.Write("Nhập năm sinh: ");
//            NamSinh = int.Parse(Console.ReadLine());
//            Console.Write("Nhập số CMND: ");
//            SoCMND = Console.ReadLine();
//        }

//        // Phương thức hiển thị thông tin
//        public virtual void HienThi()
//        {
//            Console.WriteLine($"Họ và tên: {HoTen}");
//            Console.WriteLine($"Năm sinh: {NamSinh}");
//            Console.WriteLine($"Số CMND: {SoCMND}");
//        }
//    }

//    // Lớp quản lý thông tin khách hàng kế thừa từ lớp Nguoi
//    public class KhachHang : Nguoi
//    {
//        public int SoNgayTro { get; set; }
//        public string LoaiPhong { get; set; }
//        public double GiaPhong { get; set; }

//        public KhachHang() : base() { }

//        public KhachHang(string hoTen, int namSinh, string soCMND, int soNgayTro, string loaiPhong, double giaPhong)
//            : base(hoTen, namSinh, soCMND)
//        {
//            SoNgayTro = soNgayTro;
//            LoaiPhong = loaiPhong;
//            GiaPhong = giaPhong;
//        }

//        // Ghi đè phương thức nhập
//        public override void Nhap()
//        {
//            base.Nhap();
//            Console.Write("Nhập số ngày trọ: ");
//            SoNgayTro = int.Parse(Console.ReadLine());
//            Console.Write("Nhập loại phòng (VIP/Thường): ");
//            LoaiPhong = Console.ReadLine();
//            Console.Write("Nhập giá phòng: ");
//            GiaPhong = double.Parse(Console.ReadLine());
//        }

//        // Ghi đè phương thức hiển thị
//        public override void HienThi()
//        {
//            base.HienThi();
//            Console.WriteLine($"Số ngày trọ: {SoNgayTro}");
//            Console.WriteLine($"Loại phòng: {LoaiPhong}");
//            Console.WriteLine($"Giá phòng: {GiaPhong:C}");
//            Console.WriteLine($"Tổng tiền: {TinhTien():C}");
//        }

//        // Tính tiền phòng
//        public double TinhTien()
//        {
//            return SoNgayTro * GiaPhong;
//        }
//    }

//    // Lớp quản lý khách sạn
//    public class KhachSan
//    {
//        private List<KhachHang> danhSachKhachHang;

//        public KhachSan()
//        {
//            danhSachKhachHang = new List<KhachHang>();
//        }

//        // Nhập danh sách khách hàng
//        public void NhapDanhSach()
//        {
//            Console.Write("Nhập số lượng khách trọ: ");
//            int n = int.Parse(Console.ReadLine());

//            for (int i = 0; i < n; i++)
//            {
//                Console.WriteLine($"\nNhập thông tin khách hàng thứ {i + 1}:");
//                KhachHang khach = new KhachHang();
//                khach.Nhap();
//                danhSachKhachHang.Add(khach);
//            }
//        }

//        // Hiển thị danh sách khách hàng
//        public void HienThiDanhSach()
//        {
//            if (danhSachKhachHang.Count == 0)
//            {
//                Console.WriteLine("Không có khách hàng nào trong danh sách.");
//                return;
//            }

//            Console.WriteLine("\nDanh sách khách hàng:");
//            foreach (var khach in danhSachKhachHang)
//            {
//                Console.WriteLine("-------------------");
//                khach.HienThi();
//            }
//        }

//        // Tìm kiếm khách hàng theo tên
//        public void TimKiemTheoTen()
//        {
//            Console.Write("Nhập họ và tên cần tìm: ");
//            string ten = Console.ReadLine();
//            var ketQua = danhSachKhachHang.Where(k => k.HoTen.ToLower().Contains(ten.ToLower())).ToList();

//            if (ketQua.Count == 0)
//            {
//                Console.WriteLine("Không tìm thấy khách hàng nào.");
//                return;
//            }

//            Console.WriteLine("\nKết quả tìm kiếm:");
//            foreach (var khach in ketQua)
//            {
//                Console.WriteLine("-------------------");
//                khach.HienThi();
//            }
//        }

//        // Thanh toán và trả phòng
//        public void ThanhToan()
//        {
//            Console.Write("Nhập số CMND của khách cần thanh toán: ");
//            string cmnd = Console.ReadLine();
//            var khach = danhSachKhachHang.FirstOrDefault(k => k.SoCMND == cmnd);

//            if (khach == null)
//            {
//                Console.WriteLine("Không tìm thấy khách hàng với số CMND này.");
//                return;
//            }

//            Console.WriteLine("\nThông tin thanh toán:");
//            khach.HienThi();
//            danhSachKhachHang.Remove(khach);
//            Console.WriteLine("Đã thanh toán và xóa thông tin khách hàng.");
//        }
//    }

//    // Chương trình chính
//    class Program
//    {
//        static void Main(string[] args)
//        {
//            Console.OutputEncoding = System.Text.Encoding.UTF8;
//            KhachSan khachSan = new KhachSan();
//            bool running = true;

//            while (running)
//            {
//                Console.WriteLine("\n=== QUẢN LÝ KHÁCH SẠN ===");
//                Console.WriteLine("1. Nhập danh sách khách trọ");
//                Console.WriteLine("2. Hiển thị danh sách khách trọ");
//                Console.WriteLine("3. Tìm kiếm khách hàng theo tên");
//                Console.WriteLine("4. Thanh toán và trả phòng");
//                Console.WriteLine("5. Thoát chương trình");
//                Console.Write("Chọn chức năng (1-5): ");

//                string luaChon = Console.ReadLine();

//                switch (luaChon)
//                {
//                    case "1":
//                        khachSan.NhapDanhSach();
//                        break;
//                    case "2":
//                        khachSan.HienThiDanhSach();
//                        break;
//                    case "3":
//                        khachSan.TimKiemTheoTen();
//                        break;
//                    case "4":
//                        khachSan.ThanhToan();
//                        break;
//                    case "5":
//                        running = false;
//                        Console.WriteLine("Chương trình kết thúc.");
//                        break;
//                    default:
//                        Console.WriteLine("Lựa chọn không hợp lệ. Vui lòng chọn lại.");
//                        break;
//                }
//            }
//        }
//    }
//}