﻿//using System;
//using System.Collections.Generic;
//using System.Text;

//class Nguoi
//{
//    public string hoTen;
//    public bool gioiTinh; // true = Nam, false = Nu
//    public int tuoi;

//    public Nguoi() { }

//    public Nguoi(string hoTen, bool gioiTinh, int tuoi)
//    {
//        this.hoTen = hoTen;
//        this.gioiTinh = gioiTinh;
//        this.tuoi = tuoi;
//    }

//    public virtual void In()
//    {
//        Console.WriteLine($"Ho ten: {hoTen}, Gioi tinh: {(gioiTinh ? "Nam" : "Nu")}, Tuoi: {tuoi}");
//    }
//}

//class CoQuan : Nguoi
//{
//    public string donVi;
//    public double heSoLuong;

//    public CoQuan() { }

//    public CoQuan(string hoTen, bool gioiTinh, int tuoi, string donVi, double heSoLuong)
//        : base(hoTen, gioiTinh, tuoi)
//    {
//        this.donVi = donVi;
//        this.heSoLuong = heSoLuong;
//    }

//    public override void In()
//    {
//        base.In();
//        Console.WriteLine($"Don vi: {donVi}, He so luong: {heSoLuong}, Luong: {TinhLuong()} VND");
//    }

//    public double TinhLuong()
//    {
//        const double LUONG_CO_BAN = 1050000;
//        return heSoLuong * LUONG_CO_BAN;
//    }
//}

//class Program
//{
//    static void Main()
//    {
//        Console.OutputEncoding = Encoding.UTF8;

//        List<CoQuan> danhSach = new List<CoQuan>();

//        Console.Write("Nhap so luong nhan vien: ");
//        int n = int.Parse(Console.ReadLine());

//        for (int i = 0; i < n; i++)
//        {
//            Console.WriteLine($"\nNhap thong tin cho nhan vien thu {i + 1}");

//            Console.Write("Ho ten: ");
//            string hoTen = Console.ReadLine();

//            Console.Write("Gioi tinh (1-Nam, 0-Nu): ");
//            bool gioiTinh = Console.ReadLine() == "1";

//            Console.Write("Tuoi: ");
//            int tuoi = int.Parse(Console.ReadLine());

//            Console.Write("Don vi: ");
//            string donVi = Console.ReadLine();

//            Console.Write("He so luong: ");
//            double hsl = double.Parse(Console.ReadLine());

//            danhSach.Add(new CoQuan(hoTen, gioiTinh, tuoi, donVi, hsl));
//        }

//        while (true)
//        {
//            Console.WriteLine("\n=== MENU ===");
//            Console.WriteLine("1. Hien thi thong tin nguoi co don vi la 'Phong tai chinh'");
//            Console.WriteLine("2. Tim kiem theo ho ten");
//            Console.WriteLine("3. Thoat");
//            Console.Write("Chon chuc nang: ");
//            string luaChon = Console.ReadLine();

//            if (luaChon == "1")
//            {
//                Console.WriteLine("\n== CAC NHAN VIEN THUOC PHONG TAI CHINH ==");
//                foreach (var nv in danhSach)
//                {
//                    if (nv.donVi.ToLower() == "phong tai chinh")
//                        nv.In();
//                }
//            }
//            else if (luaChon == "2")
//            {
//                Console.Write("Nhap ho ten can tim: ");
//                string tenCanTim = Console.ReadLine().ToLower();

//                Console.WriteLine("\n== KET QUA TIM KIEM ==");
//                foreach (var nv in danhSach)
//                {
//                    if (nv.hoTen.ToLower().Contains(tenCanTim))
//                        nv.In();
//                }
//            }
//            else if (luaChon == "3")
//            {
//                Console.WriteLine("Thoat chuong trinh.");
//                break;
//            }
//            else
//            {
//                Console.WriteLine("Lua chon khong hop le.");
//            }
//        }
//    }
//}
