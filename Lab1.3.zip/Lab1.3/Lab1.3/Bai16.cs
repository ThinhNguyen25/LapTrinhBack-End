﻿//using System;
//using System.Collections.Generic;

//// Lớp Diem biểu diễn một điểm trong mặt phẳng
//public class Diem
//{
//    private double x, y;

//    // Constructor mặc định
//    public Diem()
//    {
//        x = 0;
//        y = 0;
//    }

//    // Constructor có tham số
//    public Diem(double x, double y)
//    {
//        this.x = x;
//        this.y = y;
//    }

//    // Phương thức in điểm
//    public void In()
//    {
//        Console.WriteLine($"({x}, {y})");
//    }

//    // Tính khoảng cách giữa hai điểm
//    public double KhoangCach(Diem other)
//    {
//        return Math.Sqrt(Math.Pow(this.x - other.x, 2) + Math.Pow(this.y - other.y, 2));
//    }
//}

//// Lớp TamGiac biểu diễn một tam giác
//public class TamGiac
//{
//    private Diem d1, d2, d3;

//    // Constructor mặc định
//    public TamGiac()
//    {
//        d1 = new Diem();
//        d2 = new Diem();
//        d3 = new Diem();
//    }

//    // Constructor có tham số
//    public TamGiac(Diem d1, Diem d2, Diem d3)
//    {
//        this.d1 = d1;
//        this.d2 = d2;
//        this.d3 = d3;
//    }

//    // Tính chu vi tam giác
//    public double ChuVi()
//    {
//        double a = d1.KhoangCach(d2);
//        double b = d2.KhoangCach(d3);
//        double c = d3.KhoangCach(d1);
//        return a + b + c;
//    }

//    // Tính diện tích tam giác bằng công thức Heron
//    public double DienTich()
//    {
//        double a = d1.KhoangCach(d2);
//        double b = d2.KhoangCach(d3);
//        double c = d3.KhoangCach(d1);
//        double p = (a + b + c) / 2; // Nửa chu vi
//        return Math.Sqrt(p * (p - a) * (p - b) * (p - c));
//    }
//}

//// Chương trình chính
//class Program
//{
//    static void Main(string[] args)
//    {
//        Console.WriteLine("Nhap so luong tam giac:");
//        int n = int.Parse(Console.ReadLine());
//        List<TamGiac> danhSachTamGiac = new List<TamGiac>();
//        double tongChuVi = 0, tongDienTich = 0;

//        // Nhập danh sách tam giác
//        for (int i = 0; i < n; i++)
//        {
//            Console.WriteLine($"Nhap tam giac thu {i + 1}:");
//            Console.Write("Nhap diem 1 (x y): ");
//            string[] d1 = Console.ReadLine().Split();
//            Console.Write("Nhap diem 2 (x y): ");
//            string[] d2 = Console.ReadLine().Split();
//            Console.Write("Nhap diem 3 (x y): ");
//            string[] d3 = Console.ReadLine().Split();

//            TamGiac tg = new TamGiac(
//                new Diem(double.Parse(d1[0]), double.Parse(d1[1])),
//                new Diem(double.Parse(d2[0]), double.Parse(d2[1])),
//                new Diem(double.Parse(d3[0]), double.Parse(d3[1]))
//            );

//            danhSachTamGiac.Add(tg);
//            tongChuVi += tg.ChuVi();
//            tongDienTich += tg.DienTich();
//        }

//        // In kết quả
//        Console.WriteLine($"Tong chu vi: {tongChuVi:F2}");
//        Console.WriteLine($"Tong dien tich: {tongDienTich:F2}");
//    }
//}