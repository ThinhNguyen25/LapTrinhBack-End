﻿//using System;
//using System.Collections.Generic;
//using System.Linq;

//namespace QuanLyKhuPho
//{
//    // Lớp quản lý thông tin cá nhân
//    public class Nguoi
//    {
//        public string SoCMND { get; set; }
//        public string HoTen { get; set; }
//        public int Tuoi { get; set; }
//        public int NamSinh { get; set; }
//        public string NgheNghiep { get; set; }

//        public Nguoi() { }

//        public Nguoi(string soCMND, string hoTen, int tuoi, int namSinh, string ngheNghiep)
//        {
//            SoCMND = soCMND;
//            HoTen = hoTen;
//            Tuoi = tuoi;
//            NamSinh = namSinh;
//            NgheNghiep = ngheNghiep;
//        }

//        // Phương thức nhập thông tin
//        public void Nhap()
//        {
//            Console.Write("Nhập số CMND: ");
//            SoCMND = Console.ReadLine();
//            Console.Write("Nhập họ và tên: ");
//            HoTen = Console.ReadLine();
//            Console.Write("Nhập tuổi: ");
//            Tuoi = int.Parse(Console.ReadLine());
//            Console.Write("Nhập năm sinh: ");
//            NamSinh = int.Parse(Console.ReadLine());
//            Console.Write("Nhập nghề nghiệp: ");
//            NgheNghiep = Console.ReadLine();
//        }

//        // Phương thức hiển thị thông tin
//        public void HienThi()
//        {
//            Console.WriteLine($"Số CMND: {SoCMND}");
//            Console.WriteLine($"Họ và tên: {HoTen}");
//            Console.WriteLine($"Tuổi: {Tuoi}");
//            Console.WriteLine($"Năm sinh: {NamSinh}");
//            Console.WriteLine($"Nghề nghiệp: {NgheNghiep}");
//        }
//    }

//    // Lớp quản lý hộ dân
//    public class HoDan
//    {
//        public int SoThanhVien { get; set; }
//        public string SoNha { get; set; }
//        public List<Nguoi> ThanhVien { get; set; }

//        public HoDan()
//        {
//            ThanhVien = new List<Nguoi>();
//        }

//        public HoDan(int soThanhVien, string soNha, List<Nguoi> thanhVien)
//        {
//            SoThanhVien = soThanhVien;
//            SoNha = soNha;
//            ThanhVien = thanhVien;
//        }

//        // Phương thức nhập thông tin
//        public void Nhap()
//        {
//            Console.Write("Nhập số nhà: ");
//            SoNha = Console.ReadLine();
//            Console.Write("Nhập số thành viên trong hộ: ");
//            SoThanhVien = int.Parse(Console.ReadLine());

//            Console.WriteLine($"Nhập thông tin cho {SoThanhVien} thành viên:");
//            for (int i = 0; i < SoThanhVien; i++)
//            {
//                Console.WriteLine($"\nThành viên thứ {i + 1}:");
//                Nguoi nguoi = new Nguoi();
//                nguoi.Nhap();
//                ThanhVien.Add(nguoi);
//            }
//        }

//        // Phương thức hiển thị thông tin
//        public void HienThi()
//        {
//            Console.WriteLine($"Số nhà: {SoNha}");
//            Console.WriteLine($"Số thành viên: {SoThanhVien}");
//            Console.WriteLine("Thông tin các thành viên:");
//            foreach (var thanhVien in ThanhVien)
//            {
//                Console.WriteLine("-------------------");
//                thanhVien.HienThi();
//            }
//        }
//    }

//    // Lớp quản lý khu phố
//    public class KhuPho
//    {
//        private List<HoDan> danhSachHoDan;

//        public KhuPho()
//        {
//            danhSachHoDan = new List<HoDan>();
//        }

//        // Nhập danh sách hộ dân
//        public void NhapDanhSach()
//        {
//            Console.Write("Nhập số lượng hộ dân: ");
//            int n = int.Parse(Console.ReadLine());

//            for (int i = 0; i < n; i++)
//            {
//                Console.WriteLine($"\nNhập thông tin hộ dân thứ {i + 1}:");
//                HoDan hoDan = new HoDan();
//                hoDan.Nhap();
//                danhSachHoDan.Add(hoDan);
//            }
//        }

//        // Hiển thị danh sách hộ dân
//        public void HienThiDanhSach()
//        {
//            if (danhSachHoDan.Count == 0)
//            {
//                Console.WriteLine("Danh sách hộ dân trống!");
//                return;
//            }

//            Console.WriteLine("\nDanh sách hộ dân:");
//            foreach (var hoDan in danhSachHoDan)
//            {
//                Console.WriteLine("===================");
//                hoDan.HienThi();
//            }
//        }

//        // Tìm kiếm hộ dân theo họ tên
//        public void TimKiemTheoTen()
//        {
//            Console.Write("Nhập họ tên cần tìm: ");
//            string ten = Console.ReadLine();
//            bool found = false;

//            Console.WriteLine("\nKết quả tìm kiếm:");
//            foreach (var hoDan in danhSachHoDan)
//            {
//                var ketQua = hoDan.ThanhVien.Where(tv => tv.HoTen.ToLower().Contains(ten.ToLower())).ToList();
//                if (ketQua.Count > 0)
//                {
//                    Console.WriteLine("===================");
//                    hoDan.HienThi();
//                    found = true;
//                }
//            }

//            if (!found)
//                Console.WriteLine("Không tìm thấy hộ dân nào có thành viên với tên này!");
//        }

//        // Tìm kiếm hộ dân theo số nhà
//        public void TimKiemTheoSoNha()
//        {
//            Console.Write("Nhập số nhà cần tìm: ");
//            string soNha = Console.ReadLine();
//            var hoDan = danhSachHoDan.FirstOrDefault(hd => hd.SoNha == soNha);

//            if (hoDan == null)
//            {
//                Console.WriteLine("Không tìm thấy hộ dân với số nhà này!");
//                return;
//            }

//            Console.WriteLine("\nKết quả tìm kiếm:");
//            Console.WriteLine("===================");
//            hoDan.HienThi();
//        }
//    }

//    // Chương trình chính
//    class Program
//    {
//        static void Main(string[] args)
//        {
//            Console.OutputEncoding = System.Text.Encoding.UTF8;
//            KhuPho khuPho = new KhuPho();
//            bool running = true;

//            while (running)
//            {
//                Console.WriteLine("\n=== QUẢN LÝ KHU PHỐ ===");
//                Console.WriteLine("1. Nhập danh sách hộ dân");
//                Console.WriteLine("2. Hiển thị danh sách hộ dân");
//                Console.WriteLine("3. Tìm kiếm hộ dân theo họ tên");
//                Console.WriteLine("4. Tìm kiếm hộ dân theo số nhà");
//                Console.WriteLine("5. Thoát chương trình");
//                Console.Write("Chọn chức năng (1-5): ");

//                string luaChon = Console.ReadLine();

//                switch (luaChon)
//                {
//                    case "1":
//                        khuPho.NhapDanhSach();
//                        break;
//                    case "2":
//                        khuPho.HienThiDanhSach();
//                        break;
//                    case "3":
//                        khuPho.TimKiemTheoTen();
//                        break;
//                    case "4":
//                        khuPho.TimKiemTheoSoNha();
//                        break;
//                    case "5":
//                        running = false;
//                        Console.WriteLine("Chương trình kết thúc.");
//                        break;
//                    default:
//                        Console.WriteLine("Lựa chọn không hợp lệ. Vui lòng chọn lại.");
//                        break;
//                }
//            }
//        }
//    }
//}