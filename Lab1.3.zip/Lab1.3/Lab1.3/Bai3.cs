﻿//using System;
//using System.Collections.Generic;
//using System.Linq;

//namespace QuanLyTuyenSinh
//{
//    // Lớp cơ sở quản lý thông tin thí sinh
//    public abstract class ThiSinh
//    {
//        public string SoBaoDanh { get; set; }
//        public string HoTen { get; set; }
//        public string DiaChi { get; set; }
//        public int UuTien { get; set; }

//        public ThiSinh() { }

//        public ThiSinh(string soBaoDanh, string hoTen, string diaChi, int uuTien)
//        {
//            SoBaoDanh = soBaoDanh;
//            HoTen = hoTen;
//            DiaChi = diaChi;
//            UuTien = uuTien;
//        }

//        // Phương thức nhập thông tin
//        public virtual void Nhap()
//        {
//            Console.Write("Nhập số báo danh: ");
//            SoBaoDanh = Console.ReadLine();
//            Console.Write("Nhập họ và tên: ");
//            HoTen = Console.ReadLine();
//            Console.Write("Nhập địa chỉ: ");
//            DiaChi = Console.ReadLine();
//            Console.Write("Nhập mức ưu tiên (0, 1, 2,...): ");
//            UuTien = int.Parse(Console.ReadLine());
//        }

//        // Phương thức hiển thị thông tin
//        public virtual void HienThi()
//        {
//            Console.WriteLine($"Số báo danh: {SoBaoDanh}");
//            Console.WriteLine($"Họ và tên: {HoTen}");
//            Console.WriteLine($"Địa chỉ: {DiaChi}");
//            Console.WriteLine($"Mức ưu tiên: {UuTien}");
//        }

//        // Phương thức tính tổng điểm (ảo, sẽ được ghi đè)
//        public abstract double TinhTongDiem();
//    }

//    // Lớp thí sinh khối A
//    public class ThiSinhKhoiA : ThiSinh
//    {
//        public double DiemToan { get; set; }
//        public double DiemLy { get; set; }
//        public double DiemHoa { get; set; }

//        public ThiSinhKhoiA() : base() { }

//        public ThiSinhKhoiA(string soBaoDanh, string hoTen, string diaChi, int uuTien, double diemToan, double diemLy, double diemHoa)
//            : base(soBaoDanh, hoTen, diaChi, uuTien)
//        {
//            DiemToan = diemToan;
//            DiemLy = diemLy;
//            DiemHoa = diemHoa;
//        }

//        public override void Nhap()
//        {
//            base.Nhap();
//            Console.Write("Nhập điểm Toán: ");
//            DiemToan = double.Parse(Console.ReadLine());
//            Console.Write("Nhập điểm Lý: ");
//            DiemLy = double.Parse(Console.ReadLine());
//            Console.Write("Nhập điểm Hóa: ");
//            DiemHoa = double.Parse(Console.ReadLine());
//        }

//        public override void HienThi()
//        {
//            base.HienThi();
//            Console.WriteLine($"Điểm Toán: {DiemToan}");
//            Console.WriteLine($"Điểm Lý: {DiemLy}");
//            Console.WriteLine($"Điểm Hóa: {DiemHoa}");
//            Console.WriteLine($"Tổng điểm (cộng ưu tiên): {TinhTongDiem()}");
//        }

//        public override double TinhTongDiem()
//        {
//            return DiemToan + DiemLy + DiemHoa + UuTien;
//        }
//    }

//    // Lớp thí sinh khối B
//    public class ThiSinhKhoiB : ThiSinh
//    {
//        public double DiemToan { get; set; }
//        public double DiemHoa { get; set; }
//        public double DiemSinh { get; set; }

//        public ThiSinhKhoiB() : base() { }

//        public ThiSinhKhoiB(string soBaoDanh, string hoTen, string diaChi, int uuTien, double diemToan, double diemHoa, double diemSinh)
//            : base(soBaoDanh, hoTen, diaChi, uuTien)
//        {
//            DiemToan = diemToan;
//            DiemHoa = diemHoa;
//            DiemSinh = diemSinh;
//        }

//        public override void Nhap()
//        {
//            base.Nhap();
//            Console.Write("Nhập điểm Toán: ");
//            DiemToan = double.Parse(Console.ReadLine());
//            Console.Write("Nhập điểm Hóa: ");
//            DiemHoa = double.Parse(Console.ReadLine());
//            Console.Write("Nhập điểm Sinh: ");
//            DiemSinh = double.Parse(Console.ReadLine());
//        }

//        public override void HienThi()
//        {
//            base.HienThi();
//            Console.WriteLine($"Điểm Toán: {DiemToan}");
//            Console.WriteLine($"Điểm Hóa: {DiemHoa}");
//            Console.WriteLine($"Điểm Sinh: {DiemSinh}");
//            Console.WriteLine($"Tổng điểm (cộng ưu tiên): {TinhTongDiem()}");
//        }

//        public override double TinhTongDiem()
//        {
//            return DiemToan + DiemHoa + DiemSinh + UuTien;
//        }
//    }

//    // Lớp thí sinh khối C
//    public class ThiSinhKhoiC : ThiSinh
//    {
//        public double DiemVan { get; set; }
//        public double DiemSu { get; set; }
//        public double DiemDia { get; set; }

//        public ThiSinhKhoiC() : base() { }

//        public ThiSinhKhoiC(string soBaoDanh, string hoTen, string diaChi, int uuTien, double diemVan, double diemSu, double diemDia)
//            : base(soBaoDanh, hoTen, diaChi, uuTien)
//        {
//            DiemVan = diemVan;
//            DiemSu = diemSu;
//            DiemDia = diemDia;
//        }

//        public override void Nhap()
//        {
//            base.Nhap();
//            Console.Write("Nhập điểm Văn: ");
//            DiemVan = double.Parse(Console.ReadLine());
//            Console.Write("Nhập điểm Sử: ");
//            DiemSu = double.Parse(Console.ReadLine());
//            Console.Write("Nhập điểm Địa: ");
//            DiemDia = double.Parse(Console.ReadLine());
//        }

//        public override void HienThi()
//        {
//            base.HienThi();
//            Console.WriteLine($"Điểm Văn: {DiemVan}");
//            Console.WriteLine($"Điểm Sử: {DiemSu}");
//            Console.WriteLine($"Điểm Địa: {DiemDia}");
//            Console.WriteLine($"Tổng điểm (cộng ưu tiên): {TinhTongDiem()}");
//        }

//        public override double TinhTongDiem()
//        {
//            return DiemVan + DiemSu + DiemDia + UuTien;
//        }
//    }

//    // Lớp quản lý tuyển sinh
//    public class TuyenSinh
//    {
//        private List<ThiSinh> danhSachThiSinh;

//        public TuyenSinh()
//        {
//            danhSachThiSinh = new List<ThiSinh>();
//        }

//        // Nhập thông tin thí sinh
//        public void NhapThongTin()
//        {
//            Console.WriteLine("\nChọn khối thi để nhập:");
//            Console.WriteLine("1. Khối A (Toán, Lý, Hóa)");
//            Console.WriteLine("2. Khối B (Toán, Hóa, Sinh)");
//            Console.WriteLine("3. Khối C (Văn, Sử, Địa)");
//            Console.Write("Lựa chọn (1-3): ");
//            string luaChon = Console.ReadLine();

//            ThiSinh thiSinh = null;
//            switch (luaChon)
//            {
//                case "1":
//                    thiSinh = new ThiSinhKhoiA();
//                    break;
//                case "2":
//                    thiSinh = new ThiSinhKhoiB();
//                    break;
//                case "3":
//                    thiSinh = new ThiSinhKhoiC();
//                    break;
//                default:
//                    Console.WriteLine("Lựa chọn không hợp lệ!");
//                    return;
//            }

//            Console.WriteLine("\nNhập thông tin thí sinh:");
//            thiSinh.Nhap();
//            danhSachThiSinh.Add(thiSinh);
//            Console.WriteLine("Đã thêm thí sinh thành công!");
//        }

//        // Hiển thị thí sinh trúng tuyển
//        public void HienThiThiSinhTrungTuyen()
//        {
//            if (danhSachThiSinh.Count == 0)
//            {
//                Console.WriteLine("Danh sách thí sinh trống!");
//                return;
//            }

//            Console.WriteLine("\nDanh sách thí sinh trúng tuyển:");
//            bool coThiSinhTrungTuyen = false;

//            foreach (var thiSinh in danhSachThiSinh)
//            {
//                bool trungTuyen = false;
//                if (thiSinh is ThiSinhKhoiA && thiSinh.TinhTongDiem() >= 15)
//                    trungTuyen = true;
//                else if (thiSinh is ThiSinhKhoiB && thiSinh.TinhTongDiem() >= 16)
//                    trungTuyen = true;
//                else if (thiSinh is ThiSinhKhoiC && thiSinh.TinhTongDiem() >= 13.5)
//                    trungTuyen = true;

//                if (trungTuyen)
//                {
//                    Console.WriteLine("-------------------");
//                    thiSinh.HienThi();
//                    coThiSinhTrungTuyen = true;
//                }
//            }

//            if (!coThiSinhTrungTuyen)
//                Console.WriteLine("Không có thí sinh nào trúng tuyển!");
//        }

//        // Tìm kiếm thí sinh theo số báo danh
//        public void TimKiemTheoSoBaoDanh()
//        {
//            Console.Write("Nhập số báo danh cần tìm: ");
//            string soBaoDanh = Console.ReadLine();
//            var thiSinh = danhSachThiSinh.FirstOrDefault(ts => ts.SoBaoDanh == soBaoDanh);

//            if (thiSinh == null)
//            {
//                Console.WriteLine("Không tìm thấy thí sinh với số báo danh này!");
//                return;
//            }

//            Console.WriteLine("\nKết quả tìm kiếm:");
//            Console.WriteLine("-------------------");
//            thiSinh.HienThi();
//        }
//    }

//    // Chương trình chính
//    class Program
//    {
//        static void Main(string[] args)
//        {
//            Console.OutputEncoding = System.Text.Encoding.UTF8;
//            TuyenSinh tuyenSinh = new TuyenSinh();
//            bool running = true;

//            while (running)
//            {
//                Console.WriteLine("\n=== QUẢN LÝ TUYỂN SINH ===");
//                Console.WriteLine("1. Nhập thông tin thí sinh");
//                Console.WriteLine("2. Hiển thị danh sách thí sinh trúng tuyển");
//                Console.WriteLine("3. Tìm kiếm thí sinh theo số báo danh");
//                Console.WriteLine("4. Thoát chương trình");
//                Console.Write("Chọn chức năng (1-4): ");

//                string luaChon = Console.ReadLine();

//                switch (luaChon)
//                {
//                    case "1":
//                        tuyenSinh.NhapThongTin();
//                        break;
//                    case "2":
//                        tuyenSinh.HienThiThiSinhTrungTuyen();
//                        break;
//                    case "3":
//                        tuyenSinh.TimKiemTheoSoBaoDanh();
//                        break;
//                    case "4":
//                        running = false;
//                        Console.WriteLine("Chương trình kết thúc.");
//                        break;
//                    default:
//                        Console.WriteLine("Lựa chọn không hợp lệ. Vui lòng chọn lại.");
//                        break;
//                }
//            }
//        }
//    }
//}