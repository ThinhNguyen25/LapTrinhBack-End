﻿//using System;
//using System.Collections.Generic;
//using System.Linq;

//namespace QuanLyTienDien
//{
//    // Lớp quản lý thông tin khách hàng
//    public class KhachHang
//    {
//        public string HoTenChuHo { get; set; }
//        public string SoNha { get; set; }
//        public string MaSoCongTo { get; set; }

//        public KhachHang() { }

//        public KhachHang(string hoTenChuHo, string soNha, string maSoCongTo)
//        {
//            HoTenChuHo = hoTenChuHo;
//            SoNha = soNha;
//            MaSoCongTo = maSoCongTo;
//        }

//        // Phương thức nhập thông tin
//        public virtual void Nhap()
//        {
//            Console.Write("Nhập họ tên chủ hộ: ");
//            HoTenChuHo = Console.ReadLine();
//            Console.Write("Nhập số nhà: ");
//            SoNha = Console.ReadLine();
//            Console.Write("Nhập mã số công tơ: ");
//            MaSoCongTo = Console.ReadLine();
//        }

//        // Phương thức hiển thị thông tin
//        public virtual void HienThi()
//        {
//            Console.WriteLine($"Họ tên chủ hộ: {HoTenChuHo}");
//            Console.WriteLine($"Số nhà: {SoNha}");
//            Console.WriteLine($"Mã số công tơ: {MaSoCongTo}");
//        }
//    }

//    // Lớp quản lý biên lai
//    public class BienLai : KhachHang
//    {
//        public int ChiSoCu { get; set; }
//        public int ChiSoMoi { get; set; }
//        public double SoTienPhaiTra { get; set; }

//        public BienLai() : base() { }

//        public BienLai(string hoTenChuHo, string soNha, string maSoCongTo, int chiSoCu, int chiSoMoi)
//            : base(hoTenChuHo, soNha, maSoCongTo)
//        {
//            ChiSoCu = chiSoCu;
//            ChiSoMoi = chiSoMoi;
//            SoTienPhaiTra = TinhTienDien();
//        }

//        // Ghi đè phương thức nhập
//        public override void Nhap()
//        {
//            base.Nhap();
//            Console.Write("Nhập chỉ số cũ: ");
//            ChiSoCu = int.Parse(Console.ReadLine());
//            Console.Write("Nhập chỉ số mới: ");
//            ChiSoMoi = int.Parse(Console.ReadLine());
//            SoTienPhaiTra = TinhTienDien();
//        }

//        // Ghi đè phương thức hiển thị
//        public override void HienThi()
//        {
//            base.HienThi();
//            Console.WriteLine($"Chỉ số cũ: {ChiSoCu}");
//            Console.WriteLine($"Chỉ số mới: {ChiSoMoi}");
//            Console.WriteLine($"Số tiền phải trả: {SoTienPhaiTra:C}");
//        }

//        // Tính tiền điện
//        public double TinhTienDien()
//        {
//            int soDien = ChiSoMoi - ChiSoCu;
//            double tienDien = 0;

//            if (soDien < 50)
//                tienDien = soDien * 1250;
//            else if (soDien < 100)
//                tienDien = soDien * 1500;
//            else
//                tienDien = soDien * 2000;

//            return tienDien;
//        }
//    }

//    // Lớp quản lý danh sách biên lai
//    public class QuanLyBienLai
//    {
//        private List<BienLai> danhSachBienLai;

//        public QuanLyBienLai()
//        {
//            danhSachBienLai = new List<BienLai>();
//        }

//        // Nhập danh sách biên lai
//        public void NhapDanhSach()
//        {
//            Console.Write("Nhập số lượng hộ sử dụng điện: ");
//            int n = int.Parse(Console.ReadLine());

//            for (int i = 0; i < n; i++)
//            {
//                Console.WriteLine($"\nNhập thông tin biên lai thứ {i + 1}:");
//                BienLai bienLai = new BienLai();
//                bienLai.Nhap();
//                danhSachBienLai.Add(bienLai);
//            }
//        }

//        // Hiển thị danh sách biên lai
//        public void HienThiDanhSach()
//        {
//            if (danhSachBienLai.Count == 0)
//            {
//                Console.WriteLine("Danh sách biên lai trống!");
//                return;
//            }

//            Console.WriteLine("\nDanh sách biên lai:");
//            foreach (var bienLai in danhSachBienLai)
//            {
//                Console.WriteLine("-------------------");
//                bienLai.HienThi();
//            }
//        }
//    }

//    // Chương trình chính
//    class Program
//    {
//        static void Main(string[] args)
//        {
//            Console.OutputEncoding = System.Text.Encoding.UTF8;
//            QuanLyBienLai quanLy = new QuanLyBienLai();
//            bool running = true;

//            while (running)
//            {
//                Console.WriteLine("\n=== QUẢN LÝ BIÊN LAI TIỀN ĐIỆN ===");
//                Console.WriteLine("1. Nhập danh sách biên lai");
//                Console.WriteLine("2. Hiển thị danh sách biên lai");
//                Console.WriteLine("3. Thoát chương trình");
//                Console.Write("Chọn chức năng (1-3): ");

//                string luaChon = Console.ReadLine();

//                switch (luaChon)
//                {
//                    case "1":
//                        quanLy.NhapDanhSach();
//                        break;
//                    case "2":
//                        quanLy.HienThiDanhSach();
//                        break;
//                    case "3":
//                        running = false;
//                        Console.WriteLine("Chương trình kết thúc.");
//                        break;
//                    default:
//                        Console.WriteLine("Lựa chọn không hợp lệ. Vui lòng chọn lại.");
//                        break;
//                }
//            }
//        }
//    }
//}