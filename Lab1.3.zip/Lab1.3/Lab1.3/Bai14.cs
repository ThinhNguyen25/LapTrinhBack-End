﻿//using System;

//namespace QuanLyPhanSo
//{
//    // Lớp quản lý phân số
//    public class PhanSo
//    {
//        private int tuSo;
//        private int mauSo;

//        // Hàm tạo không tham số
//        public PhanSo()
//        {
//            tuSo = 0;
//            mauSo = 1;
//        }

//        // Hàm tạo có tham số
//        public PhanSo(int tu, int mau)
//        {
//            tuSo = tu;
//            if (mau == 0)
//                throw new ArgumentException("Mẫu số không thể bằng 0!");
//            mauSo = mau;
//        }

//        // Phương thức nhập phân số
//        public void Nhap()
//        {
//            Console.Write("Nhập tử số: ");
//            tuSo = int.Parse(Console.ReadLine());
//            Console.Write("Nhập mẫu số: ");
//            int mau = int.Parse(Console.ReadLine());
//            if (mau == 0)
//            {
//                throw new ArgumentException("Mẫu số không thể bằng 0!");
//            }
//            mauSo = mau;
//        }

//        // Phương thức hiển thị phân số
//        public void HienThi()
//        {
//            if (mauSo == 1)
//                Console.WriteLine($"{tuSo}");
//            else if (tuSo == 0)
//                Console.WriteLine("0");
//            else
//                Console.WriteLine($"{tuSo}/{mauSo}");
//        }

//        // Tìm ước chung lớn nhất (UCLN)
//        private int UCLN(int a, int b)
//        {
//            a = Math.Abs(a);
//            b = Math.Abs(b);
//            while (b != 0)
//            {
//                int temp = b;
//                b = a % b;
//                a = temp;
//            }
//            return a;
//        }

//        // Rút gọn phân số
//        public PhanSo RutGon()
//        {
//            int ucln = UCLN(tuSo, mauSo);
//            return new PhanSo(tuSo / ucln, mauSo / ucln);
//        }

//        // Cộng hai phân số
//        public PhanSo Cong(PhanSo other)
//        {
//            int tu = tuSo * other.mauSo + other.tuSo * mauSo;
//            int mau = mauSo * other.mauSo;
//            return new PhanSo(tu, mau).RutGon();
//        }

//        // Trừ hai phân số
//        public PhanSo Tru(PhanSo other)
//        {
//            int tu = tuSo * other.mauSo - other.tuSo * mauSo;
//            int mau = mauSo * other.mauSo;
//            return new PhanSo(tu, mau).RutGon();
//        }

//        // Nhân hai phân số
//        public PhanSo Nhan(PhanSo other)
//        {
//            int tu = tuSo * other.tuSo;
//            int mau = mauSo * other.mauSo;
//            return new PhanSo(tu, mau).RutGon();
//        }

//        // Chia hai phân số
//        public PhanSo Chia(PhanSo other)
//        {
//            if (other.tuSo == 0)
//                throw new DivideByZeroException("Không thể chia cho phân số 0!");
//            int tu = tuSo * other.mauSo;
//            int mau = mauSo * other.tuSo;
//            return new PhanSo(tu, mau).RutGon();
//        }

//        // Getter để truy cập tuSo và mauSo
//        public int TuSo
//        {
//            get { return tuSo; }
//        }

//        public int MauSo
//        {
//            get { return mauSo; }
//        }
//    }

//    // Chương trình chính
//    class Program
//    {
//        static void Main(string[] args)
//        {
//            Console.OutputEncoding = System.Text.Encoding.UTF8;
//            PhanSo A = new PhanSo();
//            PhanSo B = new PhanSo();

//            // Nhập hai phân số
//            try
//            {
//                Console.WriteLine("Nhập phân số A:");
//                A.Nhap();
//                Console.WriteLine("Nhập phân số B:");
//                B.Nhap();
//            }
//            catch (ArgumentException ex)
//            {
//                Console.WriteLine($"Lỗi: {ex.Message}");
//                return;
//            }

//            bool running = true;
//            while (running)
//            {
//                Console.WriteLine("\n=== QUẢN LÝ PHÂN SỐ ===");
//                Console.WriteLine("1. Tính tổng hai phân số");
//                Console.WriteLine("2. Tính hiệu hai phân số");
//                Console.WriteLine("3. Tính tích hai phân số");
//                Console.WriteLine("4. Tính thương hai phân số");
//                Console.WriteLine("5. Thoát chương trình");
//                Console.Write("Chọn chức năng (1-5): ");

//                string luaChon = Console.ReadLine();

//                try
//                {
//                    switch (luaChon)
//                    {
//                        case "1":
//                            Console.Write("Tổng A + B = ");
//                            A.Cong(B).HienThi();
//                            break;
//                        case "2":
//                            Console.Write("Hiệu A - B = ");
//                            A.Tru(B).HienThi();
//                            break;
//                        case "3":
//                            Console.Write("Tích A * B = ");
//                            A.Nhan(B).HienThi();
//                            break;
//                        case "4":
//                            Console.Write("Thương A / B = ");
//                            A.Chia(B).HienThi();
//                            break;
//                        case "5":
//                            running = false;
//                            Console.WriteLine("Chương trình kết thúc.");
//                            break;
//                        default:
//                            Console.WriteLine("Lựa chọn không hợp lệ. Vui lòng chọn lại.");
//                            break;
//                    }
//                }
//                catch (DivideByZeroException ex)
//                {
//                    Console.WriteLine($"Lỗi: {ex.Message}");
//                }
//            }
//        }
//    }
//}