﻿//using System;
//using System.Text.RegularExpressions;

//namespace XuLyVanBan
//{
//    // Lớp quản lý văn bản
//    public class VanBan
//    {
//        private string Chuoi;

//        // Hàm tạo không tham số
//        public VanBan()
//        {
//            Chuoi = "";
//        }

//        // Hàm tạo có tham số
//        public VanBan(string st)
//        {
//            Chuoi = st;
//        }

//        // Đếm số từ
//        public int DemSoTu()
//        {
//            if (string.IsNullOrWhiteSpace(Chuoi))
//                return 0;

//            string[] tu = Regex.Split(Chuoi.Trim(), @"\s+");
//            return tu.Length;
//        }

//        // Đếm số ký tự 'H' (không phân biệt hoa thường)
//        public int DemKyTuH()
//        {
//            return Chuoi.ToLower().Count(c => c == 'h');
//        }

//        // Chuẩn hóa xâu
//        public string ChuanHoa()
//        {
//            if (string.IsNullOrWhiteSpace(Chuoi))
//                return "";

//            // Loại bỏ khoảng trắng thừa và chuẩn hóa
//            string chuanHoa = Regex.Replace(Chuoi.Trim(), @"\s+", " ");
//            return chuanHoa;
//        }

//        // Lấy chuỗi hiện tại
//        public string LayChuoi()
//        {
//            return Chuoi;
//        }

//        // Cập nhật chuỗi
//        public void CapNhatChuoi(string st)
//        {
//            Chuoi = st;
//        }
//    }

//    // Chương trình chính
//    class Program
//    {
//        static void Main(string[] args)
//        {
//            Console.OutputEncoding = System.Text.Encoding.UTF8;
//            VanBan vanBan = new VanBan();
//            bool running = true;

//            while (running)
//            {
//                Console.WriteLine("\n=== XỬ LÝ VĂN BẢN ===");
//                Console.WriteLine("1. Nhập văn bản");
//                Console.WriteLine("2. Đếm số từ");
//                Console.WriteLine("3. Đếm số ký tự 'H'");
//                Console.WriteLine("4. Chuẩn hóa văn bản");
//                Console.WriteLine("5. Thoát chương trình");
//                Console.Write("Chọn chức năng (1-5): ");

//                string luaChon = Console.ReadLine();

//                switch (luaChon)
//                {
//                    case "1":
//                        Console.Write("Nhập văn bản: ");
//                        string input = Console.ReadLine();
//                        vanBan.CapNhatChuoi(input);
//                        Console.WriteLine("Đã nhập văn bản thành công!");
//                        break;
//                    case "2":
//                        Console.WriteLine($"Số từ trong văn bản: {vanBan.DemSoTu()}");
//                        break;
//                    case "3":
//                        Console.WriteLine($"Số ký tự 'H' (không phân biệt hoa thường): {vanBan.DemKyTuH()}");
//                        break;
//                    case "4":
//                        string chuanHoa = vanBan.ChuanHoa();
//                        Console.WriteLine($"Văn bản chuẩn hóa: {chuanHoa}");
//                        vanBan.CapNhatChuoi(chuanHoa);
//                        break;
//                    case "5":
//                        running = false;
//                        Console.WriteLine("Chương trình kết thúc.");
//                        break;
//                    default:
//                        Console.WriteLine("Lựa chọn không hợp lệ. Vui lòng chọn lại.");
//                        break;
//                }
//            }
//        }
//    }
//}