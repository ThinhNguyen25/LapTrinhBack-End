﻿//using System;
//using System.Collections.Generic;
//using System.Linq;

//namespace QuanLyDaGiac
//{
//    // Lớp quản lý đa giác
//    public class DaGiac
//    {
//        protected int soCanh;
//        protected int[] kichThuocCanh;

//        // Hàm tạo không tham số
//        public DaGiac()
//        {
//            soCanh = 0;
//            kichThuocCanh = null;
//        }

//        // Hàm tạo có tham số
//        public DaGiac(int soCanh)
//        {
//            this.soCanh = soCanh;
//            kichThuocCanh = new int[soCanh];
//        }

//        // Phương thức nhập kích thước các cạnh
//        public virtual void Nhap()
//        {
//            Console.Write("Nhập số cạnh của đa giác: ");
//            soCanh = int.Parse(Console.ReadLine());
//            if (soCanh < 3)
//            {
//                throw new ArgumentException("Số cạnh của đa giác phải lớn hơn hoặc bằng 3!");
//            }

//            kichThuocCanh = new int[soCanh];
//            Console.WriteLine("Nhập kích thước các cạnh:");
//            for (int i = 0; i < soCanh; i++)
//            {
//                Console.Write($"Cạnh {i + 1}: ");
//                kichThuocCanh[i] = int.Parse(Console.ReadLine());
//                if (kichThuocCanh[i] <= 0)
//                {
//                    throw new ArgumentException("Kích thước cạnh phải lớn hơn 0!");
//                }
//            }
//        }

//        // Phương thức in giá trị các cạnh
//        public virtual void InCacCanh()
//        {
//            if (kichThuocCanh == null)
//            {
//                Console.WriteLine("Đa giác chưa được khởi tạo!");
//                return;
//            }

//            Console.Write("Các cạnh của đa giác: ");
//            for (int i = 0; i < soCanh; i++)
//            {
//                Console.Write($"{kichThuocCanh[i]} ");
//            }
//            Console.WriteLine();
//        }

//        // Phương thức tính chu vi
//        public virtual int TinhChuVi()
//        {
//            if (kichThuocCanh == null)
//            {
//                return 0;
//            }
//            return kichThuocCanh.Sum();
//        }
//    }

//    // Lớp tam giác kế thừa từ đa giác
//    public class TamGiac : DaGiac
//    {
//        // Hàm tạo không tham số
//        public TamGiac() : base()
//        {
//            soCanh = 3;
//            kichThuocCanh = new int[3];
//        }

//        // Hàm tạo có tham số
//        public TamGiac(int a, int b, int c) : base(3)
//        {
//            kichThuocCanh[0] = a;
//            kichThuocCanh[1] = b;
//            kichThuocCanh[2] = c;
//            KiemTraTamGiac();
//        }

//        // Ghi đè phương thức nhập
//        public override void Nhap()
//        {
//            soCanh = 3;
//            kichThuocCanh = new int[3];
//            Console.WriteLine("Nhập kích thước 3 cạnh của tam giác:");
//            for (int i = 0; i < soCanh; i++)
//            {
//                Console.Write($"Cạnh {i + 1}: ");
//                kichThuocCanh[i] = int.Parse(Console.ReadLine());
//                if (kichThuocCanh[i] <= 0)
//                {
//                    throw new ArgumentException("Kích thước cạnh phải lớn hơn 0!");
//                }
//            }
//            KiemTraTamGiac();
//        }

//        // Kiểm tra điều kiện tam giác
//        private void KiemTraTamGiac()
//        {
//            int a = kichThuocCanh[0], b = kichThuocCanh[1], c = kichThuocCanh[2];
//            if (a + b <= c || b + c <= a || a + c <= b)
//            {
//                throw new ArgumentException("Ba cạnh không tạo thành tam giác!");
//            }
//        }

//        // Ghi đè phương thức tính chu vi
//        public override int TinhChuVi()
//        {
//            return base.TinhChuVi();
//        }

//        // Phương thức tính diện tích (dùng công thức Heron)
//        public double TinhDienTich()
//        {
//            double a = kichThuocCanh[0], b = kichThuocCanh[1], c = kichThuocCanh[2];
//            double p = (a + b + c) / 2; // Nửa chu vi
//            return Math.Sqrt(p * (p - a) * (p - b) * (p - c));
//        }

//        // Kiểm tra định lý Pythagoras
//        public bool LaTamGiacVuong()
//        {
//            int[] canh = kichThuocCanh.OrderBy(x => x).ToArray();
//            // Kiểm tra a^2 + b^2 = c^2 với sai số nhỏ
//            return Math.Abs(canh[0] * canh[0] + canh[1] * canh[1] - canh[2] * canh[2]) < 0.0001;
//        }
//    }

//    // Lớp quản lý danh sách tam giác
//    public class QuanLyTamGiac
//    {
//        private List<TamGiac> danhSachTamGiac;

//        public QuanLyTamGiac()
//        {
//            danhSachTamGiac = new List<TamGiac>();
//        }

//        // Nhập danh sách tam giác
//        public void NhapDanhSach()
//        {
//            Console.Write("Nhập số lượng tam giác: ");
//            int n = int.Parse(Console.ReadLine());

//            for (int i = 0; i < n; i++)
//            {
//                Console.WriteLine($"\nNhập thông tin tam giác thứ {i + 1}:");
//                TamGiac tamGiac = new TamGiac();
//                try
//                {
//                    tamGiac.Nhap();
//                    danhSachTamGiac.Add(tamGiac);
//                }
//                catch (ArgumentException ex)
//                {
//                    Console.WriteLine($"Lỗi: {ex.Message}");
//                    i--; // Nhập lại tam giác này
//                }
//            }
//        }

//        // Hiển thị tam giác thỏa mãn định lý Pythagoras
//        public void HienThiTamGiacPythagoras()
//        {
//            var ketQua = danhSachTamGiac.Where(tg => tg.LaTamGiacVuong()).ToList();

//            if (ketQua.Count == 0)
//            {
//                Console.WriteLine("Không có tam giác nào thỏa mãn định lý Pythagoras!");
//                return;
//            }

//            Console.WriteLine("\nDanh sách tam giác thỏa mãn định lý Pythagoras:");
//            foreach (var tamGiac in ketQua)
//            {
//                Console.WriteLine("-------------------");
//                tamGiac.InCacCanh();
//                Console.WriteLine($"Chu vi: {tamGiac.TinhChuVi()}");
//                Console.WriteLine($"Diện tích: {tamGiac.TinhDienTich():F2}");
//            }
//        }
//    }

//    // Chương trình chính
//    class Program
//    {
//        static void Main(string[] args)
//        {
//            Console.OutputEncoding = System.Text.Encoding.UTF8;
//            QuanLyTamGiac quanLy = new QuanLyTamGiac();
//            bool running = true;

//            while (running)
//            {
//                Console.WriteLine("\n=== QUẢN LÝ TAM GIÁC ===");
//                Console.WriteLine("1. Nhập danh sách tam giác");
//                Console.WriteLine("2. Hiển thị tam giác thỏa mãn định lý Pythagoras");
//                Console.WriteLine("3. Thoát chương trình");
//                Console.Write("Chọn chức năng (1-3): ");

//                string luaChon = Console.ReadLine();

//                try
//                {
//                    switch (luaChon)
//                    {
//                        case "1":
//                            quanLy.NhapDanhSach();
//                            break;
//                        case "2":
//                            quanLy.HienThiTamGiacPythagoras();
//                            break;
//                        case "3":
//                            running = false;
//                            Console.WriteLine("Chương trình kết thúc.");
//                            break;
//                        default:
//                            Console.WriteLine("Lựa chọn không hợp lệ. Vui lòng chọn lại.");
//                            break;
//                    }
//                }
//                catch (Exception ex)
//                {
//                    Console.WriteLine($"Lỗi: {ex.Message}");
//                }
//            }
//        }
//    }
//}