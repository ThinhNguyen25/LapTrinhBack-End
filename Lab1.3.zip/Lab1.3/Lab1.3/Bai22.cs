﻿//using System;
//using System.Collections.Generic;

//abstract class DongVat
//{
//    public string ten;

//    public DongVat(string ten)
//    {
//        this.ten = ten;
//    }

//    public abstract void Keu();
//    public virtual void Xuat()
//    {
//        Console.WriteLine($"Dong vat: {ten}");
//    }
//}

//class Cho : DongVat
//{
//    public Cho(string ten) : base(ten) { }

//    public override void Keu()
//    {
//        Console.WriteLine($"{ten} keu: Gau gau!");
//    }

//    public override void Xuat()
//    {
//        Console.WriteLine($"Loai: Cho - Ten: {ten}");
//    }
//}

//class Meo : DongVat
//{
//    public Meo(string ten) : base(ten) { }

//    public override void Keu()
//    {
//        Console.WriteLine($"{ten} keu: Meo meo!");
//    }

//    public override void Xuat()
//    {
//        Console.WriteLine($"Loai: Meo - Ten: {ten}");
//    }
//}

//class Heo : DongVat
//{
//    public Heo(string ten) : base(ten) { }

//    public override void Keu()
//    {
//        Console.WriteLine($"{ten} keu: Ut it!");
//    }

//    public override void Xuat()
//    {
//        Console.WriteLine($"Loai: Heo - Ten: {ten}");
//    }
//}

//class Program
//{
//    static void Main()
//    {
//        List<DongVat> danhSach = new List<DongVat>();

//        Console.Write("Nhap so luong dong vat: ");
//        int n = int.Parse(Console.ReadLine());

//        for (int i = 0; i < n; i++)
//        {
//            Console.WriteLine($"\nNhap dong vat thu {i + 1}");
//            Console.Write("1. Cho\n2. Meo\n3. Heo\nChon loai: ");
//            int loai = int.Parse(Console.ReadLine());

//            Console.Write("Nhap ten: ");
//            string ten = Console.ReadLine();

//            switch (loai)
//            {
//                case 1:
//                    danhSach.Add(new Cho(ten));
//                    break;
//                case 2:
//                    danhSach.Add(new Meo(ten));
//                    break;
//                case 3:
//                    danhSach.Add(new Heo(ten));
//                    break;
//                default:
//                    Console.WriteLine("Loai khong hop le!");
//                    i--; // Nhập lại
//                    break;
//            }
//        }

//        Console.WriteLine("\n== DANH SACH DONG VAT ==");
//        foreach (var dv in danhSach)
//        {
//            dv.Xuat();
//            dv.Keu();
//        }
//    }
//}
