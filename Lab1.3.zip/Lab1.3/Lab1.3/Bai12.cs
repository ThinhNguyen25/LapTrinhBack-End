﻿//using System;

//namespace QuanLyMaTran
//{
//    // Lớp quản lý ma trận
//    public class MaTran
//    {
//        private int soDong;
//        private int soCot;
//        private double[,] mang;

//        // Hàm tạo không tham số
//        public MaTran()
//        {
//            soDong = 0;
//            soCot = 0;
//            mang = null;
//        }

//        // Hàm tạo có tham số
//        public MaTran(int n, int m)
//        {
//            soDong = n;
//            soCot = m;
//            mang = new double[n, m];
//        }

//        // Phương thức nhập ma trận
//        public void Nhap()
//        {
//            Console.Write("Nhập số dòng: ");
//            soDong = int.Parse(Console.ReadLine());
//            Console.Write("Nhập số cột: ");
//            soCot = int.Parse(Console.ReadLine());

//            mang = new double[soDong, soCot];
//            Console.WriteLine("Nhập các phần tử của ma trận:");
//            for (int i = 0; i < soDong; i++)
//            {
//                for (int j = 0; j < soCot; j++)
//                {
//                    Console.Write($"Nhập phần tử [{i},{j}]: ");
//                    mang[i, j] = double.Parse(Console.ReadLine());
//                }
//            }
//        }

//        // Phương thức hiển thị ma trận
//        public void HienThi()
//        {
//            if (mang == null)
//            {
//                Console.WriteLine("Ma trận chưa được khởi tạo!");
//                return;
//            }

//            Console.WriteLine("Ma trận:");
//            for (int i = 0; i < soDong; i++)
//            {
//                for (int j = 0; j < soCot; j++)
//                {
//                    Console.Write($"{mang[i, j],8:F2}");
//                }
//                Console.WriteLine();
//            }
//        }

//        // Cộng hai ma trận
//        public MaTran Cong(MaTran other)
//        {
//            if (soDong != other.soDong || soCot != other.soCot)
//            {
//                throw new ArgumentException("Hai ma trận phải cùng cấp để thực hiện phép cộng!");
//            }

//            MaTran ketQua = new MaTran(soDong, soCot);
//            for (int i = 0; i < soDong; i++)
//            {
//                for (int j = 0; j < soCot; j++)
//                {
//                    ketQua.mang[i, j] = mang[i, j] + other.mang[i, j];
//                }
//            }
//            return ketQua;
//        }

//        // Trừ hai ma trận
//        public MaTran Tru(MaTran other)
//        {
//            if (soDong != other.soDong || soCot != other.soCot)
//            {
//                throw new ArgumentException("Hai ma trận phải cùng cấp để thực hiện phép trừ!");
//            }

//            MaTran ketQua = new MaTran(soDong, soCot);
//            for (int i = 0; i < soDong; i++)
//            {
//                for (int j = 0; j < soCot; j++)
//                {
//                    ketQua.mang[i, j] = mang[i, j] - other.mang[i, j];
//                }
//            }
//            return ketQua;
//        }

//        // Nhân hai ma trận
//        public MaTran Nhan(MaTran other)
//        {
//            if (soCot != other.soDong)
//            {
//                throw new ArgumentException("Số cột của ma trận A phải bằng số dòng của ma trận B để nhân!");
//            }

//            MaTran ketQua = new MaTran(soDong, other.soCot);
//            for (int i = 0; i < soDong; i++)
//            {
//                for (int j = 0; j < other.soCot; j++)
//                {
//                    ketQua.mang[i, j] = 0;
//                    for (int k = 0; k < soCot; k++)
//                    {
//                        ketQua.mang[i, j] += mang[i, k] * other.mang[k, j];
//                    }
//                }
//            }
//            return ketQua;
//        }

//        // Getter để truy cập thuộc tính private
//        public double[,] Mang
//        {
//            get { return mang; }
//        }

//        public int SoDong
//        {
//            get { return soDong; }
//        }

//        public int SoCot
//        {
//            get { return soCot; }
//        }
//    }

//    // Chương trình chính
//    class Program
//    {
//        static void Main(string[] args)
//        {
//            Console.OutputEncoding = System.Text.Encoding.UTF8;
//            MaTran A = new MaTran();
//            MaTran B = new MaTran();

//            // Nhập hai ma trận
//            Console.WriteLine("Nhập ma trận A:");
//            A.Nhap();
//            Console.WriteLine("\nNhập ma trận B:");
//            B.Nhap();

//            bool running = true;
//            while (running)
//            {
//                Console.WriteLine("\n=== QUẢN LÝ MA TRẬN ===");
//                Console.WriteLine("1. Tính tổng hai ma trận");
//                Console.WriteLine("2. Tính tích hai ma trận");
//                Console.WriteLine("3. Tính hiệu hai ma trận");
//                Console.WriteLine("4. Thoát chương trình");
//                Console.Write("Chọn chức năng (1-4): ");

//                string luaChon = Console.ReadLine();

//                try
//                {
//                    switch (luaChon)
//                    {
//                        case "1":
//                            Console.WriteLine("\nTổng A + B:");
//                            A.Cong(B).HienThi();
//                            break;
//                        case "2":
//                            Console.WriteLine("\nTích A * B:");
//                            A.Nhan(B).HienThi();
//                            break;
//                        case "3":
//                            Console.WriteLine("\nHiệu A - B:");
//                            A.Tru(B).HienThi();
//                            break;
//                        case "4":
//                            running = false;
//                            Console.WriteLine("Chương trình kết thúc.");
//                            break;
//                        default:
//                            Console.WriteLine("Lựa chọn không hợp lệ. Vui lòng chọn lại.");
//                            break;
//                    }
//                }
//                catch (ArgumentException ex)
//                {
//                    Console.WriteLine($"Lỗi: {ex.Message}");
//                }
//            }
//        }
//    }
//}