﻿//using System;
//using System.Collections.Generic;

//abstract class CanBo
//{
//    public string hoTen;
//    public double luongCoBan;

//    public CanBo(string ten, double luongCB)
//    {
//        hoTen = ten;
//        luongCoBan = luongCB;
//    }

//    public abstract double TinhLuong();
//    public abstract void Xuat();
//}

//class NhanVien : CanBo
//{
//    public int soNgayCong;

//    public NhanVien(string ten, double luongCB, int ngayCong) : base(ten, luongCB)
//    {
//        soNgayCong = ngayCong;
//    }

//    public override double TinhLuong()
//    {
//        return luongCoBan + soNgayCong * 100000;
//    }

//    public override void Xuat()
//    {
//        Console.WriteLine($"Nhan vien - {hoTen}, Luong co ban: {luongCoBan}, So ngay cong: {soNgayCong}, Luong: {TinhLuong():N0}");
//    }
//}

//class GiamDoc : CanBo
//{
//    public double heSoChucVu;

//    public GiamDoc(string ten, double luongCB, double heSo) : base(ten, luongCB)
//    {
//        heSoChucVu = heSo;
//    }

//    public override double TinhLuong()
//    {
//        return luongCoBan * heSoChucVu;
//    }

//    public override void Xuat()
//    {
//        Console.WriteLine($"Giam doc - {hoTen}, Luong co ban: {luongCoBan}, He so chuc vu: {heSoChucVu}, Luong: {TinhLuong():N0}");
//    }
//}

//class Program
//{
//    static void Main()
//    {
//        List<CanBo> danhSach = new List<CanBo>();

//        Console.Write("Nhap so luong can bo: ");
//        int n = int.Parse(Console.ReadLine());

//        for (int i = 0; i < n; i++)
//        {
//            Console.WriteLine($"\nNhap thong tin can bo thu {i + 1}");
//            Console.Write("1. Nhan vien\n2. Giam doc\nChon loai can bo: ");
//            int loai = int.Parse(Console.ReadLine());

//            Console.Write("Nhap ho ten: ");
//            string ten = Console.ReadLine();

//            Console.Write("Nhap luong co ban: ");
//            double luongCB = double.Parse(Console.ReadLine());

//            if (loai == 1)
//            {
//                Console.Write("Nhap so ngay cong: ");
//                int ngayCong = int.Parse(Console.ReadLine());

//                danhSach.Add(new NhanVien(ten, luongCB, ngayCong));
//            }
//            else if (loai == 2)
//            {
//                Console.Write("Nhap he so chuc vu: ");
//                double heSo = double.Parse(Console.ReadLine());

//                danhSach.Add(new GiamDoc(ten, luongCB, heSo));
//            }
//            else
//            {
//                Console.WriteLine("Loai khong hop le!");
//                i--; // nhập lại
//            }
//        }

//        Console.WriteLine("\n== DANH SACH CAN BO ==");
//        foreach (var cb in danhSach)
//            cb.Xuat();

//        double tongLuong = 0;
//        double luongMax = 0;
//        CanBo cbMax = null;

//        foreach (var cb in danhSach)
//        {
//            double luong = cb.TinhLuong();
//            tongLuong += luong;

//            if (luong > luongMax)
//            {
//                luongMax = luong;
//                cbMax = cb;
//            }
//        }

//        Console.WriteLine($"\nTong luong tat ca can bo: {tongLuong:N0}");

//        Console.WriteLine("\n== CAN BO CO LUONG CAO NHAT ==");
//        cbMax.Xuat();
//    }
//}
