﻿//using System;
//using System.Collections.Generic;

//abstract class HinhHoc
//{
//    public abstract double TinhDienTich();
//    public abstract void Xuat();
//}

//class HinhTron : HinhHoc
//{
//    public double banKinh;

//    public HinhTron(double r)
//    {
//        banKinh = r;
//    }

//    public override double TinhDienTich()
//    {
//        return Math.PI * banKinh * banKinh;
//    }

//    public override void Xuat()
//    {
//        Console.WriteLine($"Hinh tron - Ban kinh: {banKinh}, Dien tich: {TinhDienTich():F2}");
//    }
//}

//class HinhChuNhat : HinhHoc
//{
//    public double chieuDai;
//    public double chieuRong;

//    public HinhChuNhat(double dai, double rong)
//    {
//        chieuDai = dai;
//        chieuRong = rong;
//    }

//    public override double TinhDienTich()
//    {
//        return chieuDai * chieuRong;
//    }

//    public override void Xuat()
//    {
//        Console.WriteLine($"Hinh chu nhat - Dai: {chieuDai}, Rong: {chieuRong}, Dien tich: {TinhDienTich():F2}");
//    }
//}

//class Program
//{
//    static void Main()
//    {
//        List<HinhHoc> danhSach = new List<HinhHoc>();

//        Console.Write("Nhap so luong hinh: ");
//        int n = int.Parse(Console.ReadLine());

//        for (int i = 0; i < n; i++)
//        {
//            Console.WriteLine($"\nNhap hinh thu {i + 1}");
//            Console.Write("1. Hinh tron\n2. Hinh chu nhat\nChon loai hinh: ");
//            int loai = int.Parse(Console.ReadLine());

//            if (loai == 1)
//            {
//                Console.Write("Nhap ban kinh: ");
//                double r = double.Parse(Console.ReadLine());
//                danhSach.Add(new HinhTron(r));
//            }
//            else if (loai == 2)
//            {
//                Console.Write("Nhap chieu dai: ");
//                double dai = double.Parse(Console.ReadLine());

//                Console.Write("Nhap chieu rong: ");
//                double rong = double.Parse(Console.ReadLine());

//                danhSach.Add(new HinhChuNhat(dai, rong));
//            }
//            else
//            {
//                Console.WriteLine("Loai hinh khong hop le.");
//                i--; // nhập lại
//            }
//        }

//        Console.WriteLine("\n== DANH SACH CAC HINH ==");
//        foreach (var hinh in danhSach)
//            hinh.Xuat();

//        double tongDienTich = 0;
//        double maxDienTich = 0;
//        HinhHoc hinhMax = null;

//        foreach (var hinh in danhSach)
//        {
//            double dt = hinh.TinhDienTich();
//            tongDienTich += dt;

//            if (dt > maxDienTich)
//            {
//                maxDienTich = dt;
//                hinhMax = hinh;
//            }
//        }

//        Console.WriteLine($"\nTong dien tich tat ca cac hinh: {tongDienTich:F2}");

//        Console.WriteLine("\n== HINH CO DIEN TICH LON NHAT ==");
//        hinhMax.Xuat();
//    }
//}
