﻿//using System;

//namespace QuanLySoPhuc
//{
//    // Lớp quản lý số phức
//    public class SoPhuc
//    {
//        private double phanThuc;
//        private double phanAo;

//        // Hàm tạo không tham số
//        public SoPhuc()
//        {
//            phanThuc = 0;
//            phanAo = 0;
//        }

//        // Hàm tạo có tham số
//        public SoPhuc(double a, double b)
//        {
//            phanThuc = a;
//            phanAo = b;
//        }

//        // Phương thức nhập số phức
//        public void Nhap()
//        {
//            Console.Write("Nhập phần thực: ");
//            phanThuc = double.Parse(Console.ReadLine());
//            Console.Write("Nhập phần ảo: ");
//            phanAo = double.Parse(Console.ReadLine());
//        }

//        // Phương thức hiển thị số phức
//        public void HienThi()
//        {
//            if (phanAo >= 0)
//                Console.WriteLine($"{phanThuc} + {phanAo}i");
//            else
//                Console.WriteLine($"{phanThuc} - {Math.Abs(phanAo)}i");
//        }

//        // Cộng hai số phức
//        public SoPhuc Cong(SoPhuc other)
//        {
//            return new SoPhuc(phanThuc + other.phanThuc, phanAo + other.phanAo);
//        }

//        // Trừ hai số phức
//        public SoPhuc Tru(SoPhuc other)
//        {
//            return new SoPhuc(phanThuc - other.phanThuc, phanAo - other.phanAo);
//        }

//        // Nhân hai số phức
//        public SoPhuc Nhan(SoPhuc other)
//        {
//            double thuc = phanThuc * other.phanThuc - phanAo * other.phanAo;
//            double ao = phanThuc * other.phanAo + phanAo * other.phanThuc;
//            return new SoPhuc(thuc, ao);
//        }

//        // Chia hai số phức
//        public SoPhuc Chia(SoPhuc other)
//        {
//            double mau = other.phanThuc * other.phanThuc + other.phanAo * other.phanAo;
//            if (mau == 0)
//            {
//                throw new DivideByZeroException("Không thể chia cho số phức 0!");
//            }
//            double thuc = (phanThuc * other.phanThuc + phanAo * other.phanAo) / mau;
//            double ao = (phanAo * other.phanThuc - phanThuc * other.phanAo) / mau;
//            return new SoPhuc(thuc, ao);
//        }

//        // Getter để truy cập phanThuc và phanAo
//        public double PhanThuc
//        {
//            get { return phanThuc; }
//        }

//        public double PhanAo
//        {
//            get { return phanAo; }
//        }
//    }

//    // Chương trình chính
//    class Program
//    {
//        static void Main(string[] args)
//        {
//            Console.OutputEncoding = System.Text.Encoding.UTF8;
//            SoPhuc A = new SoPhuc();
//            SoPhuc B = new SoPhuc();

//            // Nhập hai số phức
//            Console.WriteLine("Nhập số phức A:");
//            A.Nhap();
//            Console.WriteLine("Nhập số phức B:");
//            B.Nhap();

//            bool running = true;
//            while (running)
//            {
//                Console.WriteLine("\n=== QUẢN LÝ SỐ PHỨC ===");
//                Console.WriteLine("1. Tính tổng hai số phức");
//                Console.WriteLine("2. Tính hiệu hai số phức");
//                Console.WriteLine("3. Tính tích hai số phức");
//                Console.WriteLine("4. Tính thương hai số phức");
//                Console.WriteLine("5. Thoát chương trình");
//                Console.Write("Chọn chức năng (1-5): ");

//                string luaChon = Console.ReadLine();

//                switch (luaChon)
//                {
//                    case "1":
//                        Console.Write("Tổng A + B = ");
//                        A.Cong(B).HienThi();
//                        break;
//                    case "2":
//                        Console.Write("Hiệu A - B = ");
//                        A.Tru(B).HienThi();
//                        break;
//                    case "3":
//                        Console.Write("Tích A * B = ");
//                        A.Nhan(B).HienThi();
//                        break;
//                    case "4":
//                        try
//                        {
//                            Console.Write("Thương A / B = ");
//                            A.Chia(B).HienThi();
//                        }
//                        catch (DivideByZeroException ex)
//                        {
//                            Console.WriteLine(ex.Message);
//                        }
//                        break;
//                    case "5":
//                        running = false;
//                        Console.WriteLine("Chương trình kết thúc.");
//                        break;
//                    default:
//                        Console.WriteLine("Lựa chọn không hợp lệ. Vui lòng chọn lại.");
//                        break;
//                }
//            }
//        }
//    }
//}