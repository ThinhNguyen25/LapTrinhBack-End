﻿//using System;
//using System.Collections.Generic;
//using System.Linq;

//namespace QuanLyPhuongTien
//{
//    // Lớp cơ sở quản lý phương tiện giao thông
//    public abstract class PTGT
//    {
//        public string HangSanXuat { get; set; }
//        public int NamSanXuat { get; set; }
//        public double GiaBan { get; set; }
//        public string Mau { get; set; }

//        public PTGT() { }

//        public PTGT(string hangSanXuat, int namSanXuat, double giaBan, string mau)
//        {
//            HangSanXuat = hangSanXuat;
//            NamSanXuat = namSanXuat;
//            GiaBan = giaBan;
//            Mau = mau;
//        }

//        // Phương thức nhập thông tin
//        public virtual void Nhap()
//        {
//            Console.Write("Nhập hãng sản xuất: ");
//            HangSanXuat = Console.ReadLine();
//            Console.Write("Nhập năm sản xuất: ");
//            NamSanXuat = int.Parse(Console.ReadLine());
//            Console.Write("Nhập giá bán: ");
//            GiaBan = double.Parse(Console.ReadLine());
//            Console.Write("Nhập màu: ");
//            Mau = Console.ReadLine();
//        }

//        // Phương thức hiển thị thông tin
//        public virtual void HienThi()
//        {
//            Console.WriteLine($"Hãng sản xuất: {HangSanXuat}");
//            Console.WriteLine($"Năm sản xuất: {NamSanXuat}");
//            Console.WriteLine($"Giá bán: {GiaBan:C}");
//            Console.WriteLine($"Màu: {Mau}");
//        }
//    }

//    // Lớp Ô tô kế thừa từ PTGT
//    public class OTo : PTGT
//    {
//        public int SoChoNgoi { get; set; }
//        public string KieuDongCo { get; set; }

//        public OTo() : base() { }

//        public OTo(string hangSanXuat, int namSanXuat, double giaBan, string mau, int soChoNgoi, string kieuDongCo)
//            : base(hangSanXuat, namSanXuat, giaBan, mau)
//        {
//            SoChoNgoi = soChoNgoi;
//            KieuDongCo = kieuDongCo;
//        }

//        public override void Nhap()
//        {
//            base.Nhap();
//            Console.Write("Nhập số chỗ ngồi: ");
//            SoChoNgoi = int.Parse(Console.ReadLine());
//            Console.Write("Nhập kiểu động cơ: ");
//            KieuDongCo = Console.ReadLine();
//        }

//        public override void HienThi()
//        {
//            base.HienThi();
//            Console.WriteLine($"Số chỗ ngồi: {SoChoNgoi}");
//            Console.WriteLine($"Kiểu động cơ: {KieuDongCo}");
//        }
//    }

//    // Lớp Xe máy kế thừa từ PTGT
//    public class XeMay : PTGT
//    {
//        public double CongSuat { get; set; }

//        public XeMay() : base() { }

//        public XeMay(string hangSanXuat, int namSanXuat, double giaBan, string mau, double congSuat)
//            : base(hangSanXuat, namSanXuat, giaBan, mau)
//        {
//            CongSuat = congSuat;
//        }

//        public override void Nhap()
//        {
//            base.Nhap();
//            Console.Write("Nhập công suất (kW): ");
//            CongSuat = double.Parse(Console.ReadLine());
//        }

//        public override void HienThi()
//        {
//            base.HienThi();
//            Console.WriteLine($"Công suất: {CongSuat} kW");
//        }
//    }

//    // Lớp Xe tải kế thừa từ PTGT
//    public class XeTai : PTGT
//    {
//        public double TrongTai { get; set; }

//        public XeTai() : base() { }

//        public XeTai(string hangSanXuat, int namSanXuat, double giaBan, string mau, double trongTai)
//            : base(hangSanXuat, namSanXuat, giaBan, mau)
//        {
//            TrongTai = trongTai;
//        }

//        public override void Nhap()
//        {
//            base.Nhap();
//            Console.Write("Nhập trọng tải (tấn): ");
//            TrongTai = double.Parse(Console.ReadLine());
//        }

//        public override void HienThi()
//        {
//            base.HienThi();
//            Console.WriteLine($"Trọng tải: {TrongTai} tấn");
//        }
//    }

//    // Lớp quản lý phương tiện giao thông
//    public class QLPTGT
//    {
//        private List<PTGT> danhSachPhuongTien;

//        public QLPTGT()
//        {
//            danhSachPhuongTien = new List<PTGT>();
//        }

//        // Nhập đăng ký phương tiện
//        public void NhapDangKy()
//        {
//            Console.WriteLine("\nChọn loại phương tiện để đăng ký:");
//            Console.WriteLine("1. Ô tô");
//            Console.WriteLine("2. Xe máy");
//            Console.WriteLine("3. Xe tải");
//            Console.Write("Lựa chọn (1-3): ");
//            string luaChon = Console.ReadLine();

//            PTGT phuongTien = null;
//            switch (luaChon)
//            {
//                case "1":
//                    phuongTien = new OTo();
//                    break;
//                case "2":
//                    phuongTien = new XeMay();
//                    break;
//                case "3":
//                    phuongTien = new XeTai();
//                    break;
//                default:
//                    Console.WriteLine("Lựa chọn không hợp lệ!");
//                    return;
//            }

//            Console.WriteLine("\nNhập thông tin phương tiện:");
//            phuongTien.Nhap();
//            danhSachPhuongTien.Add(phuongTien);
//            Console.WriteLine("Đã đăng ký phương tiện thành công!");
//        }

//        // Tìm phương tiện theo màu
//        public void TimTheoMau()
//        {
//            Console.Write("Nhập màu cần tìm: ");
//            string mau = Console.ReadLine();
//            var ketQua = danhSachPhuongTien.Where(pt => pt.Mau.ToLower().Contains(mau.ToLower())).ToList();

//            if (ketQua.Count == 0)
//            {
//                Console.WriteLine("Không tìm thấy phương tiện nào có màu này!");
//                return;
//            }

//            Console.WriteLine("\nKết quả tìm kiếm theo màu:");
//            foreach (var pt in ketQua)
//            {
//                Console.WriteLine("-------------------");
//                pt.HienThi();
//            }
//        }

//        // Tìm phương tiện theo năm sản xuất
//        public void TimTheoNamSanXuat()
//        {
//            Console.Write("Nhập năm sản xuất cần tìm: ");
//            int nam = int.Parse(Console.ReadLine());
//            var ketQua = danhSachPhuongTien.Where(pt => pt.NamSanXuat == nam).ToList();

//            if (ketQua.Count == 0)
//            {
//                Console.WriteLine("Không tìm thấy phương tiện nào sản xuất trong năm này!");
//                return;
//            }

//            Console.WriteLine("\nKết quả tìm kiếm theo năm sản xuất:");
//            foreach (var pt in ketQua)
//            {
//                Console.WriteLine("-------------------");
//                pt.HienThi();
//            }
//        }
//    }

//    // Chương trình chính
//    class Program
//    {
//        static void Main(string[] args)
//        {
//            Console.OutputEncoding = System.Text.Encoding.UTF8;
//            QLPTGT quanLy = new QLPTGT();
//            bool running = true;

//            while (running)
//            {
//                Console.WriteLine("\n=== QUẢN LÝ PHƯƠNG TIỆN GIAO THÔNG ===");
//                Console.WriteLine("1. Nhập đăng ký phương tiện");
//                Console.WriteLine("2. Tìm phương tiện theo màu");
//                Console.WriteLine("3. Tìm phương tiện theo năm sản xuất");
//                Console.WriteLine("4. Thoát chương trình");
//                Console.Write("Chọn chức năng (1-4): ");

//                string luaChon = Console.ReadLine();

//                switch (luaChon)
//                {
//                    case "1":
//                        quanLy.NhapDangKy();
//                        break;
//                    case "2":
//                        quanLy.TimTheoMau();
//                        break;
//                    case "3":
//                        quanLy.TimTheoNamSanXuat();
//                        break;
//                    case "4":
//                        running = false;
//                        Console.WriteLine("Chương trình kết thúc.");
//                        break;
//                    default:
//                        Console.WriteLine("Lựa chọn không hợp lệ. Vui lòng chọn lại.");
//                        break;
//                }
//            }
//        }
//    }
//}