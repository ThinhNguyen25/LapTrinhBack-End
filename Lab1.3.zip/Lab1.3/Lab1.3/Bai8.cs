﻿//using System.Net.Mime;
//using System;
//using System.Collections.Generic;
//using System.Linq;

//namespace QuanLyMuonSach
//{
//    // Lớp quản lý thông tin sinh viên
//    public class SinhVien
//    {
//        public string HoTen { get; set; }
//        public int NamSinh { get; set; }
//        public string Lop { get; set; }
//        public string MaSoSinhVien { get; set; }

//        public SinhVien() { }

//        public SinhVien(string hoTen, int namSinh, string lop, string maSoSinhVien)
//        {
//            HoTen = hoTen;
//            NamSinh = namSinh;
//            Lop = lop;
//            MaSoSinhVien = maSoSinhVien;
//        }

//        // Phương thức nhập thông tin
//        public virtual void Nhap()
//        {
//            Console.Write("Nhập họ và tên: ");
//            HoTen = Console.ReadLine();
//            Console.Write("Nhập năm sinh: ");
//            NamSinh = int.Parse(Console.ReadLine());
//            Console.Write("Nhập lớp: ");
//            Lop = Console.ReadLine();
//            Console.Write("Nhập mã số sinh viên: ");
//            MaSoSinhVien = Console.ReadLine();
//        }

//        // Phương thức hiển thị thông tin
//        public virtual void HienThi()
//        {
//            Console.WriteLine($"Họ và tên: {HoTen}");
//            Console.WriteLine($"Năm sinh: {NamSinh}");
//            Console.WriteLine($"Lớp: {Lop}");
//            Console.WriteLine($"Mã số sinh viên: {MaSoSinhVien}");
//        }
//    }

//    // Lớp quản lý thẻ mượn
//    public class TheMuon : SinhVien
//    {
//        public string SoPhieuMuon { get; set; }
//        public DateTime NgayMuon { get; set; }
//        public DateTime HanTra { get; set; }
//        public string SoHieuSach { get; set; }

//        public TheMuon() : base() { }

//        public TheMuon(string hoTen, int namSinh, string lop, string maSoSinhVien, string soPhieuMuon, DateTime ngayMuon, DateTime hanTra, string soHieuSach)
//            : base(hoTen, namSinh, lop, maSoSinhVien)
//        {
//            SoPhieuMuon = soPhieuMuon;
//            NgayMuon = ngayMuon;
//            HanTra = hanTra;
//            SoHieuSach = soHieuSach;
//        }

//        // Ghi đè phương thức nhập
//        public override void Nhap()
//        {
//            base.Nhap();
//            Console.Write("Nhập số phiếu mượn: ");
//            SoPhieuMuon = Console.ReadLine();
//            Console.Write("Nhập ngày mượn (DD/MM/YYYY): ");
//            NgayMuon = DateTime.Parse(Console.ReadLine());
//            Console.Write("Nhập hạn trả (DD/MM/YYYY): ");
//            HanTra = DateTime.Parse(Console.ReadLine());
//            Console.Write("Nhập số hiệu sách: ");
//            SoHieuSach = Console.ReadLine();
//        }

//        // Ghi đè phương thức hiển thị
//        public override void HienThi()
//        {
//            base.HienThi();
//            Console.WriteLine($"Số phiếu mượn: {SoPhieuMuon}");
//            Console.WriteLine($"Ngày mượn: {NgayMuon:dd/MM/yyyy}");
//            Console.WriteLine($"Hạn trả: {HanTra:dd/MM/yyyy}");
//            Console.WriteLine($"Số hiệu sách: {SoHieuSach}");
//        }
//    }

//    // Lớp quản lý danh sách thẻ mượn
//    public class QuanLyTheMuon
//    {
//        private List<TheMuon> danhSachTheMuon;

//        public QuanLyTheMuon()
//        {
//            danhSachTheMuon = new List<TheMuon>();
//        }

//        // Nhập danh sách thẻ mượn
//        public void NhapDanhSach()
//        {
//            Console.Write("Nhập số lượng sinh viên mượn sách: ");
//            int n = int.Parse(Console.ReadLine());

//            for (int i = 0; i < n; i++)
//            {
//                Console.WriteLine($"\nNhập thông tin thẻ mượn thứ {i + 1}:");
//                TheMuon theMuon = new TheMuon();
//                theMuon.Nhap();
//                danhSachTheMuon.Add(theMuon);
//            }
//        }

//        // Hiển thị sinh viên đến hạn trả sách
//        public void HienThiDenHanTra()
//        {
//            DateTime ngayHienTai = DateTime.Today;
//            var ketQua = danhSachTheMuon.Where(tm => tm.HanTra.Date <= ngayHienTai).ToList();

//            if (ketQua.Count == 0)
//            {
//                Console.WriteLine("Không có sinh viên nào đến hạn trả sách!");
//                return;
//            }

//            Console.WriteLine("\nDanh sách sinh viên đến hạn trả sách:");
//            foreach (var theMuon in ketQua)
//            {
//                Console.WriteLine("-------------------");
//                theMuon.HienThi();
//            }
//        }

//        // Tìm kiếm sinh viên theo mã số sinh viên
//        public void TimKiemTheoMaSo()
//        {
//            Console.Write("Nhập mã số sinh viên cần tìm: ");
//            string maSo = Console.ReadLine();
//            var ketQua = danhSachTheMuon.Where(tm => tm.MaSoSinhVien == maSo).ToList();

//            if (ketQua.Count == 0)
//            {
//                Console.WriteLine("Không tìm thấy sinh viên với mã số này!");
//                return;
//            }

//            Console.WriteLine("\nKết quả tìm kiếm:");
//            foreach (var theMuon in ketQua)
//            {
//                Console.WriteLine("-------------------");
//                theMuon.HienThi();
//            }
//        }
//    }

//    // Chương trình chính
//    class Program
//    {
//        static void Main(string[] args)
//        {
//            Console.OutputEncoding = System.Text.Encoding.UTF8;
//            QuanLyTheMuon quanLy = new QuanLyTheMuon();
//            bool running = true;

//            while (running)
//            {
//                Console.WriteLine("\n=== QUẢN LÝ MƯỢN SÁCH ===");
//                Console.WriteLine("1. Nhập danh sách sinh viên mượn sách");
//                Console.WriteLine("2. Hiển thị sinh viên đến hạn trả sách");
//                Console.WriteLine("3. Tìm kiếm sinh viên theo mã số sinh viên");
//                Console.WriteLine("4. Thoát chương trình");
//                Console.Write("Chọn chức năng (1-4): ");

//                string luaChon = Console.ReadLine();

//                switch (luaChon)
//                {
//                    case "1":
//                        quanLy.NhapDanhSach();
//                        break;
//                    case "2":
//                        quanLy.HienThiDenHanTra();
//                        break;
//                    case "3":
//                        quanLy.TimKiemTheoMaSo();
//                        break;
//                    case "4":
//                        running = false;
//                        Console.WriteLine("Chương trình kết thúc.");
//                        break;
//                    default:
//                        Console.WriteLine("Lựa chọn không hợp lệ. Vui lòng chọn lại.");
//                        break;
//                }
//            }
//        }
//    }
//}