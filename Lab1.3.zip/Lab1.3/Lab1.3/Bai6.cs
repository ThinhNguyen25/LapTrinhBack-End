﻿//using System;
//using System.Collections.Generic;
//using System.Linq;

//namespace QuanLyHocSinh
//{
//    // Lớp quản lý thông tin cá nhân
//    public class Nguoi
//    {
//        public string HoTen { get; set; }
//        public int Tuoi { get; set; }
//        public int NamSinh { get; set; }
//        public string QueQuan { get; set; }
//        public string GioiTinh { get; set; }

//        public Nguoi() { }

//        public Nguoi(string hoTen, int tuoi, int namSinh, string queQuan, string gioiTinh)
//        {
//            HoTen = hoTen;
//            Tuoi = tuoi;
//            NamSinh = namSinh;
//            QueQuan = queQuan;
//            GioiTinh = gioiTinh;
//        }

//        // Phương thức nhập thông tin
//        public virtual void Nhap()
//        {
//            Console.Write("Nhập họ và tên: ");
//            HoTen = Console.ReadLine();
//            Console.Write("Nhập tuổi: ");
//            Tuoi = int.Parse(Console.ReadLine());
//            Console.Write("Nhập năm sinh: ");
//            NamSinh = int.Parse(Console.ReadLine());
//            Console.Write("Nhập quê quán: ");
//            QueQuan = Console.ReadLine();
//            Console.Write("Nhập giới tính (Nam/Nữ): ");
//            GioiTinh = Console.ReadLine();
//        }

//        // Phương thức hiển thị thông tin
//        public virtual void HienThi()
//        {
//            Console.WriteLine($"Họ và tên: {HoTen}");
//            Console.WriteLine($"Tuổi: {Tuoi}");
//            Console.WriteLine($"Năm sinh: {NamSinh}");
//            Console.WriteLine($"Quê quán: {QueQuan}");
//            Console.WriteLine($"Giới tính: {GioiTinh}");
//        }
//    }

//    // Lớp quản lý hồ sơ học sinh
//    public class HSHocSinh : Nguoi
//    {
//        public string Lop { get; set; }
//        public string KhoaHoc { get; set; }
//        public string KyHoc { get; set; }

//        public HSHocSinh() : base() { }

//        public HSHocSinh(string hoTen, int tuoi, int namSinh, string queQuan, string gioiTinh, string lop, string khoaHoc, string kyHoc)
//            : base(hoTen, tuoi, namSinh, queQuan, gioiTinh)
//        {
//            Lop = lop;
//            KhoaHoc = khoaHoc;
//            KyHoc = kyHoc;
//        }

//        // Ghi đè phương thức nhập
//        public override void Nhap()
//        {
//            base.Nhap();
//            Console.Write("Nhập lớp: ");
//            Lop = Console.ReadLine();
//            Console.Write("Nhập khóa học: ");
//            KhoaHoc = Console.ReadLine();
//            Console.Write("Nhập kỳ học: ");
//            KyHoc = Console.ReadLine();
//        }

//        // Ghi đè phương thức hiển thị
//        public override void HienThi()
//        {
//            base.HienThi();
//            Console.WriteLine($"Lớp: {Lop}");
//            Console.WriteLine($"Khóa học: {KhoaHoc}");
//            Console.WriteLine($"Kỳ học: {KyHoc}");
//        }
//    }

//    // Lớp quản lý danh sách học sinh
//    public class QuanLyHocSinh
//    {
//        private List<HSHocSinh> danhSachHocSinh;

//        public QuanLyHocSinh()
//        {
//            danhSachHocSinh = new List<HSHocSinh>();
//        }

//        // Nhập danh sách học sinh
//        public void NhapDanhSach()
//        {
//            Console.Write("Nhập số lượng học sinh: ");
//            int n = int.Parse(Console.ReadLine());

//            for (int i = 0; i < n; i++)
//            {
//                Console.WriteLine($"\nNhập thông tin học sinh thứ {i + 1}:");
//                HSHocSinh hocSinh = new HSHocSinh();
//                hocSinh.Nhap();
//                danhSachHocSinh.Add(hocSinh);
//            }
//        }

//        // Hiển thị học sinh nữ sinh năm 1985
//        public void HienThiHocSinhNu1985()
//        {
//            var ketQua = danhSachHocSinh.Where(hs => hs.GioiTinh.ToLower() == "nữ" && hs.NamSinh == 1985).ToList();

//            if (ketQua.Count == 0)
//            {
//                Console.WriteLine("Không có học sinh nữ sinh năm 1985!");
//                return;
//            }

//            Console.WriteLine("\nDanh sách học sinh nữ sinh năm 1985:");
//            foreach (var hocSinh in ketQua)
//            {
//                Console.WriteLine("-------------------");
//                hocSinh.HienThi();
//            }
//        }

//        // Tìm kiếm học sinh theo quê quán
//        public void TimKiemTheoQueQuan()
//        {
//            Console.Write("Nhập quê quán cần tìm: ");
//            string queQuan = Console.ReadLine();
//            var ketQua = danhSachHocSinh.Where(hs => hs.QueQuan.ToLower().Contains(queQuan.ToLower())).ToList();

//            if (ketQua.Count == 0)
//            {
//                Console.WriteLine("Không tìm thấy học sinh nào có quê quán này!");
//                return;
//            }

//            Console.WriteLine("\nKết quả tìm kiếm:");
//            foreach (var hocSinh in ketQua)
//            {
//                Console.WriteLine("-------------------");
//                hocSinh.HienThi();
//            }
//        }
//    }

//    // Chương trình chính
//    class Program
//    {
//        static void Main(string[] args)
//        {
//            Console.OutputEncoding = System.Text.Encoding.UTF8;
//            QuanLyHocSinh quanLy = new QuanLyHocSinh();
//            bool running = true;

//            while (running)
//            {
//                Console.WriteLine("\n=== QUẢN LÝ HỌC SINH ===");
//                Console.WriteLine("1. Nhập danh sách học sinh");
//                Console.WriteLine("2. Hiển thị học sinh nữ sinh năm 1985");
//                Console.WriteLine("3. Tìm kiếm học sinh theo quê quán");
//                Console.WriteLine("4. Thoát chương trình");
//                Console.Write("Chọn chức năng (1-4): ");

//                string luaChon = Console.ReadLine();

//                switch (luaChon)
//                {
//                    case "1":
//                        quanLy.NhapDanhSach();
//                        break;
//                    case "2":
//                        quanLy.HienThiHocSinhNu1985();
//                        break;
//                    case "3":
//                        quanLy.TimKiemTheoQueQuan();
//                        break;
//                    case "4":
//                        running = false;
//                        Console.WriteLine("Chương trình kết thúc.");
//                        break;
//                    default:
//                        Console.WriteLine("Lựa chọn không hợp lệ. Vui lòng chọn lại.");
//                        break;
//                }
//            }
//        }
//    }
//}