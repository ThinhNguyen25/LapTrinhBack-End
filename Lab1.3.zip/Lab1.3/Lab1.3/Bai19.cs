﻿//using System;
//using System.Collections.Generic;
//using System.Text;

//class Nguoi
//{
//    public string hoTen;
//    public bool gioiTinh; // true = Nam, false = Nu
//    public int tuoi;

//    public Nguoi() { }

//    public Nguoi(string hoTen, bool gioiTinh, int tuoi)
//    {
//        this.hoTen = hoTen;
//        this.gioiTinh = gioiTinh;
//        this.tuoi = tuoi;
//    }

//    public virtual void In()
//    {
//        Console.WriteLine($"Ho ten: {hoTen}, Gioi tinh: {(gioiTinh ? "Nam" : "Nu")}, Tuoi: {tuoi}");
//    }
//}

//class ThiSinh : Nguoi
//{
//    public double diemThi;

//    public ThiSinh() { }

//    public ThiSinh(string hoTen, bool gioiTinh, int tuoi, double diemThi)
//        : base(hoTen, gioiTinh, tuoi)
//    {
//        this.diemThi = diemThi;
//    }

//    public bool LaThiSinhDau()
//    {
//        return diemThi >= 5.0;
//    }

//    public override void In()
//    {
//        base.In();
//        Console.WriteLine($"Diem thi: {diemThi}, Trang thai: {(LaThiSinhDau() ? "Dau" : "Rot")}");
//    }
//}

//class Program
//{
//    static void Main()
//    {
//        Console.OutputEncoding = Encoding.UTF8;

//        List<ThiSinh> danhSach = new List<ThiSinh>();

//        Console.Write("Nhap so luong thi sinh: ");
//        int n = int.Parse(Console.ReadLine());

//        for (int i = 0; i < n; i++)
//        {
//            Console.WriteLine($"\nNhap thong tin cho thi sinh thu {i + 1}");

//            Console.Write("Ho ten: ");
//            string hoTen = Console.ReadLine();

//            Console.Write("Gioi tinh (1-Nam, 0-Nu): ");
//            bool gioiTinh = Console.ReadLine() == "1";

//            Console.Write("Tuoi: ");
//            int tuoi = int.Parse(Console.ReadLine());

//            Console.Write("Diem thi: ");
//            double diem = double.Parse(Console.ReadLine());

//            danhSach.Add(new ThiSinh(hoTen, gioiTinh, tuoi, diem));
//        }

//        while (true)
//        {
//            Console.WriteLine("\n=== MENU ===");
//            Console.WriteLine("1. Hien thi danh sach thi sinh dau");
//            Console.WriteLine("2. Tim kiem theo ho ten");
//            Console.WriteLine("3. Thoat");
//            Console.Write("Chon chuc nang: ");
//            string chon = Console.ReadLine();

//            if (chon == "1")
//            {
//                Console.WriteLine("\n== DANH SACH THI SINH DAU ==");
//                foreach (var ts in danhSach)
//                {
//                    if (ts.LaThiSinhDau())
//                        ts.In();
//                }
//            }
//            else if (chon == "2")
//            {
//                Console.Write("Nhap ho ten can tim: ");
//                string tenTim = Console.ReadLine().ToLower();

//                Console.WriteLine("\n== KET QUA TIM KIEM ==");
//                foreach (var ts in danhSach)
//                {
//                    if (ts.hoTen.ToLower().Contains(tenTim))
//                        ts.In();
//                }
//            }
//            else if (chon == "3")
//            {
//                Console.WriteLine("Thoat chuong trinh.");
//                break;
//            }
//            else
//            {
//                Console.WriteLine("Lua chon khong hop le.");
//            }
//        }
//    }
//}
