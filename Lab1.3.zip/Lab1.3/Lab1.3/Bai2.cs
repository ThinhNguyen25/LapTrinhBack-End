﻿//using System;
//using System.Collections.Generic;
//using System.Linq;

//namespace QuanLyThuVien
//{
//    // Lớp cơ sở quản lý tài liệu
//    public abstract class TaiLieu
//    {
//        public string MaTaiLieu { get; set; }
//        public string TenNhaXuatBan { get; set; }
//        public int SoBanPhatHanh { get; set; }

//        public TaiLieu() { }

//        public TaiLieu(string maTaiLieu, string tenNhaXuatBan, int soBanPhatHanh)
//        {
//            MaTaiLieu = maTaiLieu;
//            TenNhaXuatBan = tenNhaXuatBan;
//            SoBanPhatHanh = soBanPhatHanh;
//        }

//        // Phương thức nhập thông tin
//        public virtual void Nhap()
//        {
//            Console.Write("Nhập mã tài liệu: ");
//            MaTaiLieu = Console.ReadLine();
//            Console.Write("Nhập tên nhà xuất bản: ");
//            TenNhaXuatBan = Console.ReadLine();
//            Console.Write("Nhập số bản phát hành: ");
//            SoBanPhatHanh = int.Parse(Console.ReadLine());
//        }

//        // Phương thức hiển thị thông tin
//        public virtual void HienThi()
//        {
//            Console.WriteLine($"Mã tài liệu: {MaTaiLieu}");
//            Console.WriteLine($"Tên nhà xuất bản: {TenNhaXuatBan}");
//            Console.WriteLine($"Số bản phát hành: {SoBanPhatHanh}");
//        }
//    }

//    // Lớp Sách kế thừa từ TaiLieu
//    public class Sach : TaiLieu
//    {
//        public string TenTacGia { get; set; }
//        public int SoTrang { get; set; }

//        public Sach() : base() { }

//        public Sach(string maTaiLieu, string tenNhaXuatBan, int soBanPhatHanh, string tenTacGia, int soTrang)
//            : base(maTaiLieu, tenNhaXuatBan, soBanPhatHanh)
//        {
//            TenTacGia = tenTacGia;
//            SoTrang = soTrang;
//        }

//        public override void Nhap()
//        {
//            base.Nhap();
//            Console.Write("Nhập tên tác giả: ");
//            TenTacGia = Console.ReadLine();
//            Console.Write("Nhập số trang: ");
//            SoTrang = int.Parse(Console.ReadLine());
//        }

//        public override void HienThi()
//        {
//            base.HienThi();
//            Console.WriteLine($"Tên tác giả: {TenTacGia}");
//            Console.WriteLine($"Số trang: {SoTrang}");
//        }
//    }

//    // Lớp Tạp chí kế thừa từ TaiLieu
//    public class TapChi : TaiLieu
//    {
//        public int SoPhatHanh { get; set; }
//        public int ThangPhatHanh { get; set; }

//        public TapChi() : base() { }

//        public TapChi(string maTaiLieu, string tenNhaXuatBan, int soBanPhatHanh, int soPhatHanh, int thangPhatHanh)
//            : base(maTaiLieu, tenNhaXuatBan, soBanPhatHanh)
//        {
//            SoPhatHanh = soPhatHanh;
//            ThangPhatHanh = thangPhatHanh;
//        }

//        public override void Nhap()
//        {
//            base.Nhap();
//            Console.Write("Nhập số phát hành: ");
//            SoPhatHanh = int.Parse(Console.ReadLine());
//            Console.Write("Nhập tháng phát hành: ");
//            ThangPhatHanh = int.Parse(Console.ReadLine());
//        }

//        public override void HienThi()
//        {
//            base.HienThi();
//            Console.WriteLine($"Số phát hành: {SoPhatHanh}");
//            Console.WriteLine($"Tháng phát hành: {ThangPhatHanh}");
//        }
//    }

//    // Lớp Báo kế thừa từ TaiLieu
//    public class Bao : TaiLieu
//    {
//        public string NgayPhatHanh { get; set; }

//        public Bao() : base() { }

//        public Bao(string maTaiLieu, string tenNhaXuatBan, int soBanPhatHanh, string ngayPhatHanh)
//            : base(maTaiLieu, tenNhaXuatBan, soBanPhatHanh)
//        {
//            NgayPhatHanh = ngayPhatHanh;
//        }

//        public override void Nhap()
//        {
//            base.Nhap();
//            Console.Write("Nhập ngày phát hành (DD/MM/YYYY): ");
//            NgayPhatHanh = Console.ReadLine();
//        }

//        public override void HienThi()
//        {
//            base.HienThi();
//            Console.WriteLine($"Ngày phát hành: {NgayPhatHanh}");
//        }
//    }

//    // Lớp quản lý tài liệu
//    public class QuanLyTaiLieu
//    {
//        private List<TaiLieu> danhSachTaiLieu;

//        public QuanLyTaiLieu()
//        {
//            danhSachTaiLieu = new List<TaiLieu>();
//        }

//        // Nhập thông tin tài liệu
//        public void NhapThongTin()
//        {
//            Console.WriteLine("\nChọn loại tài liệu để nhập:");
//            Console.WriteLine("1. Sách");
//            Console.WriteLine("2. Tạp chí");
//            Console.WriteLine("3. Báo");
//            Console.Write("Lựa chọn (1-3): ");
//            string luaChon = Console.ReadLine();

//            TaiLieu taiLieu = null;
//            switch (luaChon)
//            {
//                case "1":
//                    taiLieu = new Sach();
//                    break;
//                case "2":
//                    taiLieu = new TapChi();
//                    break;
//                case "3":
//                    taiLieu = new Bao();
//                    break;
//                default:
//                    Console.WriteLine("Lựa chọn không hợp lệ!");
//                    return;
//            }

//            Console.WriteLine("\nNhập thông tin tài liệu:");
//            taiLieu.Nhap();
//            danhSachTaiLieu.Add(taiLieu);
//            Console.WriteLine("Đã thêm tài liệu thành công!");
//        }

//        // Hiển thị danh sách tài liệu
//        public void HienThiDanhSach()
//        {
//            if (danhSachTaiLieu.Count == 0)
//            {
//                Console.WriteLine("Danh sách tài liệu trống!");
//                return;
//            }

//            Console.WriteLine("\nDanh sách tài liệu:");
//            foreach (var taiLieu in danhSachTaiLieu)
//            {
//                Console.WriteLine("-------------------");
//                taiLieu.HienThi();
//            }
//        }

//        // Tìm kiếm tài liệu theo loại
//        public void TimKiemTheoLoai()
//        {
//            Console.WriteLine("\nChọn loại tài liệu để tìm kiếm:");
//            Console.WriteLine("1. Sách");
//            Console.WriteLine("2. Tạp chí");
//            Console.WriteLine("3. Báo");
//            Console.Write("Lựa chọn (1-3): ");
//            string luaChon = Console.ReadLine();

//            Type loaiTaiLieu = null;
//            switch (luaChon)
//            {
//                case "1":
//                    loaiTaiLieu = typeof(Sach);
//                    break;
//                case "2":
//                    loaiTaiLieu = typeof(TapChi);
//                    break;
//                case "3":
//                    loaiTaiLieu = typeof(Bao);
//                    break;
//                default:
//                    Console.WriteLine("Lựa chọn không hợp lệ!");
//                    return;
//            }

//            var ketQua = danhSachTaiLieu.Where(tl => tl.GetType() == loaiTaiLieu).ToList();

//            if (ketQua.Count == 0)
//            {
//                Console.WriteLine("Không tìm thấy tài liệu nào thuộc loại này!");
//                return;
//            }

//            Console.WriteLine("\nKết quả tìm kiếm:");
//            foreach (var taiLieu in ketQua)
//            {
//                Console.WriteLine("-------------------");
//                taiLieu.HienThi();
//            }
//        }
//    }

//    // Chương trình chính
//    class Program
//    {
//        static void Main(string[] args)
//        {
//            Console.OutputEncoding = System.Text.Encoding.UTF8;
//            QuanLyTaiLieu quanLy = new QuanLyTaiLieu();
//            bool running = true;

//            while (running)
//            {
//                Console.WriteLine("\n=== QUẢN LÝ THƯ VIỆN ===");
//                Console.WriteLine("1. Nhập thông tin tài liệu");
//                Console.WriteLine("2. Hiển thị danh sách tài liệu");
//                Console.WriteLine("3. Tìm kiếm tài liệu theo loại");
//                Console.WriteLine("4. Thoát chương trình");
//                Console.Write("Chọn chức năng (1-4): ");

//                string luaChon = Console.ReadLine();

//                switch (luaChon)
//                {
//                    case "1":
//                        quanLy.NhapThongTin();
//                        break;
//                    case "2":
//                        quanLy.HienThiDanhSach();
//                        break;
//                    case "3":
//                        quanLy.TimKiemTheoLoai();
//                        break;
//                    case "4":
//                        running = false;
//                        Console.WriteLine("Chương trình kết thúc.");
//                        break;
//                    default:
//                        Console.WriteLine("Lựa chọn không hợp lệ. Vui lòng chọn lại.");
//                        break;
//                }
//            }
//        }
//    }
//}