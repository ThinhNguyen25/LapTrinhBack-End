﻿//using System;
//using System.Collections.Generic;

//namespace QLCB
//{
//    // Lớp cha CanBo
//    public class CanBo
//    {
//        protected string hoTen;
//        protected int namSinh;
//        protected string gioiTinh;
//        protected string diaChi;

//        public CanBo() { }

//        public CanBo(string hoTen, int namSinh, string gioiTinh, string diaChi)
//        {
//            this.hoTen = hoTen;
//            this.namSinh = namSinh;
//            this.gioiTinh = gioiTinh;
//            this.diaChi = diaChi;
//        }

//        public virtual void Nhap()
//        {
//            Console.Write("Nhap ho ten: ");
//            hoTen = Console.ReadLine();
//            Console.Write("Nhap nam sinh: ");
//            namSinh = int.Parse(Console.ReadLine());
//            Console.Write("Nhap gioi tinh: ");
//            gioiTinh = Console.ReadLine();
//            Console.Write("Nhap dia chi: ");
//            diaChi = Console.ReadLine();
//        }

//        public virtual void HienThi()
//        {
//            Console.WriteLine($"Ho ten: {hoTen}");
//            Console.WriteLine($"Nam sinh: {namSinh}");
//            Console.WriteLine($"Gioi tinh: {gioiTinh}");
//            Console.WriteLine($"Dia chi: {diaChi}");
//        }

//        public string GetHoTen()
//        {
//            return hoTen;
//        }
//    }

//    // Lớp CongNhan kế thừa từ CanBo
//    public class CongNhan : CanBo
//    {
//        private string bac;

//        public CongNhan() : base() { }

//        public CongNhan(string hoTen, int namSinh, string gioiTinh, string diaChi, string bac)
//            : base(hoTen, namSinh, gioiTinh, diaChi)
//        {
//            this.bac = bac;
//        }

//        public override void Nhap()
//        {
//            base.Nhap();
//            Console.Write("Nhap bac (vi du: 3/7): ");
//            bac = Console.ReadLine();
//        }

//        public override void HienThi()
//        {
//            base.HienThi();
//            Console.WriteLine($"Bac: {bac}");
//        }
//    }

//    // Lớp KySu kế thừa từ CanBo
//    public class KySu : CanBo
//    {
//        private string nganhDaoTao;

//        public KySu() : base() { }

//        public KySu(string hoTen, int namSinh, string gioiTinh, string diaChi, string nganhDaoTao)
//            : base(hoTen, namSinh, gioiTinh, diaChi)
//        {
//            this.nganhDaoTao = nganhDaoTao;
//        }

//        public override void Nhap()
//        {
//            base.Nhap();
//            Console.Write("Nhap nganh dao tao: ");
//            nganhDaoTao = Console.ReadLine();
//        }

//        public override void HienThi()
//        {
//            base.HienThi();
//            Console.WriteLine($"Nganh dao tao: {nganhDaoTao}");
//        }
//    }

//    // Lớp NhanVien kế thừa từ CanBo
//    public class NhanVien : CanBo
//    {
//        private string congViec;

//        public NhanVien() : base() { }

//        public NhanVien(string hoTen, int namSinh, string gioiTinh, string diaChi, string congViec)
//            : base(hoTen, namSinh, gioiTinh, diaChi)
//        {
//            this.congViec = congViec;
//        }

//        public override void Nhap()
//        {
//            base.Nhap();
//            Console.Write("Nhap cong viec: ");
//            congViec = Console.ReadLine();
//        }

//        public override void HienThi()
//        {
//            base.HienThi();
//            Console.WriteLine($"Cong viec: {congViec}");
//        }
//    }

//    // Lớp QLCB quản lý danh sách cán bộ
//    public class QLCB
//    {
//        private List<CanBo> danhSachCanBo;

//        public QLCB()
//        {
//            danhSachCanBo = new List<CanBo>();
//        }

//        public void NhapThongTinMoi()
//        {
//            Console.WriteLine("Chon loai can bo muon nhap:");
//            Console.WriteLine("1. Cong nhan");
//            Console.WriteLine("2. Ky su");
//            Console.WriteLine("3. Nhan vien");
//            Console.Write("Nhap lua chon (1-3): ");

//            int luaChon;
//            while (!int.TryParse(Console.ReadLine(), out luaChon) || luaChon < 1 || luaChon > 3)
//            {
//                Console.Write("Lua chon khong hop le. Nhap lai (1-3): ");
//            }

//            CanBo canBo = null;
//            switch (luaChon)
//            {
//                case 1:
//                    canBo = new CongNhan();
//                    break;
//                case 2:
//                    canBo = new KySu();
//                    break;
//                case 3:
//                    canBo = new NhanVien();
//                    break;
//            }

//            canBo.Nhap();
//            danhSachCanBo.Add(canBo);
//            Console.WriteLine("Them can bo thanh cong!");
//        }

//        public void TimKiemTheoHoTen()
//        {
//            Console.Write("Nhap ho ten can tim: ");
//            string hoTen = Console.ReadLine();
//            bool found = false;

//            foreach (CanBo cb in danhSachCanBo)
//            {
//                if (cb.GetHoTen().ToLower().Contains(hoTen.ToLower()))
//                {
//                    cb.HienThi();
//                    Console.WriteLine("----------------");
//                    found = true;
//                }
//            }

//            if (!found)
//            {
//                Console.WriteLine("Khong tim thay can bo voi ho ten nay!");
//            }
//        }

//        public void HienThiDanhSach()
//        {
//            if (danhSachCanBo.Count == 0)
//            {
//                Console.WriteLine("Danh sach can bo trong!");
//                return;
//            }

//            Console.WriteLine("Danh sach tat ca can bo:");
//            foreach (CanBo cb in danhSachCanBo)
//            {
//                cb.HienThi();
//                Console.WriteLine("----------------");
//            }
//        }

//        public void ChayChuongTrinh()
//        {
//            while (true)
//            {
//                Console.WriteLine("\nCHUONG TRINH QUAN LY CAN BO");
//                Console.WriteLine("1. Nhap thong tin moi cho can bo");
//                Console.WriteLine("2. Tim kiem theo ho ten");
//                Console.WriteLine("3. Hien thi danh sach can bo");
//                Console.WriteLine("4. Thoat");
//                Console.Write("Nhap lua chon (1-4): ");

//                int luaChon;
//                while (!int.TryParse(Console.ReadLine(), out luaChon) || luaChon < 1 || luaChon > 4)
//                {
//                    Console.Write("Lua chon khong hop le. Nhap lai (1-4): ");
//                }

//                switch (luaChon)
//                {
//                    case 1:
//                        NhapThongTinMoi();
//                        break;
//                    case 2:
//                        TimKiemTheoHoTen();
//                        break;
//                    case 3:
//                        HienThiDanhSach();
//                        break;
//                    case 4:
//                        Console.WriteLine("Tam biet!");
//                        return;
//                }
//            }
//        }
//    }

//    class Program
//    {
//        static void Main(string[] args)
//        {
//            Console.OutputEncoding = System.Text.Encoding.UTF8;
//            QLCB quanLy = new QLCB();
//            quanLy.ChayChuongTrinh();
//        }
//    }
//}