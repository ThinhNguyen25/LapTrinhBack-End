﻿//using System;
//using System.Collections.Generic;
//using System.Linq;

//namespace QuanLyLuongCBGV
//{
//    // Lớp quản lý thông tin cá nhân
//    public class Nguoi
//    {
//        public string HoTen { get; set; }
//        public int NamSinh { get; set; }
//        public string QueQuan { get; set; }
//        public string SoCMND { get; set; }

//        public Nguoi() { }

//        public Nguoi(string hoTen, int namSinh, string queQuan, string soCMND)
//        {
//            HoTen = hoTen;
//            NamSinh = namSinh;
//            QueQuan = queQuan;
//            SoCMND = soCMND;
//        }

//        // Phương thức nhập thông tin
//        public virtual void Nhap()
//        {
//            Console.Write("Nhập họ và tên: ");
//            HoTen = Console.ReadLine();
//            Console.Write("Nhập năm sinh: ");
//            NamSinh = int.Parse(Console.ReadLine());
//            Console.Write("Nhập quê quán: ");
//            QueQuan = Console.ReadLine();
//            Console.Write("Nhập số CMND: ");
//            SoCMND = Console.ReadLine();
//        }

//        // Phương thức hiển thị thông tin
//        public virtual void HienThi()
//        {
//            Console.WriteLine($"Họ và tên: {HoTen}");
//            Console.WriteLine($"Năm sinh: {NamSinh}");
//            Console.WriteLine($"Quê quán: {QueQuan}");
//            Console.WriteLine($"Số CMND: {SoCMND}");
//        }
//    }

//    // Lớp quản lý cán bộ giáo viên
//    public class CBGV : Nguoi
//    {
//        public double LuongCung { get; set; }
//        public double Thuong { get; set; }
//        public double Phat { get; set; }
//        public double LuongThucLinh { get; set; }

//        public CBGV() : base() { }

//        public CBGV(string hoTen, int namSinh, string queQuan, string soCMND, double luongCung, double thuong, double phat)
//            : base(hoTen, namSinh, queQuan, soCMND)
//        {
//            LuongCung = luongCung;
//            Thuong = thuong;
//            Phat = phat;
//            LuongThucLinh = TinhLuongThucLinh();
//        }

//        // Ghi đè phương thức nhập
//        public override void Nhap()
//        {
//            base.Nhap();
//            Console.Write("Nhập lương cứng: ");
//            LuongCung = double.Parse(Console.ReadLine());
//            Console.Write("Nhập thưởng: ");
//            Thuong = double.Parse(Console.ReadLine());
//            Console.Write("Nhập phạt: ");
//            Phat = double.Parse(Console.ReadLine());
//            LuongThucLinh = TinhLuongThucLinh();
//        }

//        // Ghi đè phương thức hiển thị
//        public override void HienThi()
//        {
//            base.HienThi();
//            Console.WriteLine($"Lương cứng: {LuongCung:C}");
//            Console.WriteLine($"Thưởng: {Thuong:C}");
//            Console.WriteLine($"Phạt: {Phat:C}");
//            Console.WriteLine($"Lương thực lĩnh: {LuongThucLinh:C}");
//        }

//        // Tính lương thực lĩnh
//        public double TinhLuongThucLinh()
//        {
//            return LuongCung + Thuong - Phat;
//        }
//    }

//    // Lớp quản lý danh sách cán bộ giáo viên
//    public class QuanLyCBGV
//    {
//        private List<CBGV> danhSachCBGV;

//        public QuanLyCBGV()
//        {
//            danhSachCBGV = new List<CBGV>();
//        }

//        // Nhập danh sách cán bộ giáo viên
//        public void NhapDanhSach()
//        {
//            Console.Write("Nhập số lượng cán bộ giáo viên: ");
//            int n = int.Parse(Console.ReadLine());

//            for (int i = 0; i < n; i++)
//            {
//                Console.WriteLine($"\nNhập thông tin cán bộ giáo viên thứ {i + 1}:");
//                CBGV cbgv = new CBGV();
//                cbgv.Nhap();
//                danhSachCBGV.Add(cbgv);
//            }
//        }

//        // Hiển thị cán bộ giáo viên có lương thực lĩnh trên 5 triệu
//        public void HienThiLuongTren5Trieu()
//        {
//            var ketQua = danhSachCBGV.Where(cbgv => cbgv.LuongThucLinh > 5000000).ToList();

//            if (ketQua.Count == 0)
//            {
//                Console.WriteLine("Không có cán bộ giáo viên nào có lương thực lĩnh trên 5 triệu!");
//                return;
//            }

//            Console.WriteLine("\nDanh sách cán bộ giáo viên có lương thực lĩnh trên 5 triệu:");
//            foreach (var cbgv in ketQua)
//            {
//                Console.WriteLine("-------------------");
//                cbgv.HienThi();
//            }
//        }

//        // Tìm kiếm cán bộ giáo viên theo quê quán
//        public void TimKiemTheoQueQuan()
//        {
//            Console.Write("Nhập quê quán cần tìm: ");
//            string queQuan = Console.ReadLine();
//            var ketQua = danhSachCBGV.Where(cbgv => cbgv.QueQuan.ToLower().Contains(queQuan.ToLower())).ToList();

//            if (ketQua.Count == 0)
//            {
//                Console.WriteLine("Không tìm thấy cán bộ giáo viên nào có quê quán này!");
//                return;
//            }

//            Console.WriteLine("\nKết quả tìm kiếm:");
//            foreach (var cbgv in ketQua)
//            {
//                Console.WriteLine("-------------------");
//                cbgv.HienThi();
//            }
//        }
//    }

//    // Chương trình chính
//    class Program
//    {
//        static void Main(string[] args)
//        {
//            Console.OutputEncoding = System.Text.Encoding.UTF8;
//            QuanLyCBGV quanLy = new QuanLyCBGV();
//            bool running = true;

//            while (running)
//            {
//                Console.WriteLine("\n=== QUẢN LÝ LƯƠNG CBGV ===");
//                Console.WriteLine("1. Nhập danh sách cán bộ giáo viên");
//                Console.WriteLine("2. Hiển thị cán bộ giáo viên có lương trên 5 triệu");
//                Console.WriteLine("3. Tìm kiếm cán bộ giáo viên theo quê quán");
//                Console.WriteLine("4. Thoát chương trình");
//                Console.Write("Chọn chức năng (1-4): ");

//                string luaChon = Console.ReadLine();

//                switch (luaChon)
//                {
//                    case "1":
//                        quanLy.NhapDanhSach();
//                        break;
//                    case "2":
//                        quanLy.HienThiLuongTren5Trieu();
//                        break;
//                    case "3":
//                        quanLy.TimKiemTheoQueQuan();
//                        break;
//                    case "4":
//                        running = false;
//                        Console.WriteLine("Chương trình kết thúc.");
//                        break;
//                    default:
//                        Console.WriteLine("Lựa chọn không hợp lệ. Vui lòng chọn lại.");
//                        break;
//                }
//            }
//        }
//    }
//}